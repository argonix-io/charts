# Worker queues

Enable `finopsWorker.enabled` to deploy a dedicated worker consuming `finops`.
With this option enabled, the general worker consumes only `celery`. When it is
disabled (the default), the general worker consumes both queues for compatibility.
Deploy the application, scanner and inference images with chart 0.2.0 together.

FinOps collection, allocation, optimization, anomaly detection and budget tasks
route to `finops`. Agent investigations and approved remediation retain the
general worker's larger memory budget. Monitor tasks and monitor alert evaluation
and delivery route to `monitors`; external alert ingestion and AI investigations
remain on their existing queues.

Routing applies to newly published messages. Existing messages in `celery` drain
there; do not purge them during rollout. Explicit queue overrides on custom
DatabaseScheduler entries take precedence over application routes.

The dedicated FinOps worker defaults to one process, a 1Gi memory request and a
4Gi limit. Its 660-second shutdown grace accommodates the ten-minute cost-sync
and vSphere task limits. Other FinOps tasks can have different execution limits.
Size requests and limits against peak measurements after rollout.

# Dedicated AI Code Hunter worker

The AI tab is available on Code projects without selecting a scanner engine.
Chart 0.2.5 deploys `hunterWorker` by default so its queue has a consumer.
`security.run_code_analysis` stays on `scanner`;
`security.run_code_hunter` consumes only `code-hunter`. Resume and
recovery also dispatch AI batches to that dedicated queue. Schedule dispatch and
recovery coordination remain on the general queue. There is no AI fallback to a
scanner or general worker, so without a Hunter consumer AI batches remain queued.

Image precedence is `hunterWorker.image` when its repository is configured,
then a configured `scannerWorker.image`, then the standard API `image`. Both
`Dockerfile.django` and `Dockerfile.scanner` ship Git, the organization LLM SDKs
and `argonix.scanner_celery` under `/app`. Deploy the selected image from the same
revision as the application. A custom image must preserve that working directory,
readable application files and these runtime dependencies. The startup probe
checks them and the writable temporary volumes. The worker loads no local model
weights and requires no GPU. `hunterWorker.enabled=false` is still supported,
but an external `code-hunter` consumer is then needed for AI reviews to progress.

Defaults are one replica, concurrency one, prefetch one, a 250m CPU/1Gi memory
request and a one CPU/2Gi memory limit. This reservation is added by the default
deployment even before a user starts an AI review. Writable checkout storage is an ephemeral
5Gi volume; `/tmp` is an additional 1Gi volume. The filesystem otherwise stays
read-only and the worker runs as UID/GID 10001 without Linux capabilities or an
automounted Kubernetes service account token. Override resources based on
repository size and measured peak use. Increasing replicas or concurrency also
increases simultaneous hosted LLM requests and potential cost.

The 1020-second shutdown grace accommodates the Hunter task's 900-second soft
and 960-second hard limits, including checkout. Celery receives SIGTERM directly
and can finish the active batch. A killed batch can be redelivered against the
same checkpoint; already completed batches are preserved. Deployment does not
clear messages from any queue.

`hunterWorker.networkPolicy.enabled` is optional and disabled by default. When
enabled, the policy denies ingress and allows DNS plus public HTTPS for Git and
hosted LLM endpoints. Unlike the scanner policy, it does not implicitly allow
all private networks. Set `privateEgressCidrs` to the required private DB, broker,
Git or LLM destinations; `privateEgressPorts` defaults to TCP 443, 5432 and 6379.
Use `extraEgress` for namespace/pod selectors, TLS broker ports or other private
LLM/artifact storage endpoints. CNI handling of service address translation must
be considered when choosing CIDRs; a namespace/pod selector is often appropriate
for in-cluster DB and broker pods. Other applicable policies can add permissions.

The optional `hunterWorker.existingSecret` allows a restricted environment. It
must retain the database and broker connection settings, shared `SECRET_KEY`
and any required artifact-storage credentials. Organization LLM credentials are
read through the existing organization settings, not copied into chart values.

Validate the chart locally without accessing a cluster:

```sh
helm dependency build charts/api
python -m unittest discover -s charts/api/tests -q
helm lint charts/api
```

# Dedicated inference (breaking change in 0.2.0)

All embedding and reranking calls use the internal `-inference:8001` service.
There is no local backend or local fallback. The API and workers no longer ship
model weights, PyTorch, Transformers or ONNX Runtime. The dedicated image loads
BGE-M3 and bge-reranker-v2-m3 once, using the existing ONNX calculation.

The service always has one replica/process. Inference runs serially in batches
of eight, with at most eight pending/active requests; saturation returns HTTP
503. Clients have bounded timeouts and do not retry automatically. During a
service restart, RAG requests can fail until the models are ready. The existing
retrieval behaviour on reranking failure (returning unreranked passages) remains.

Helm sets `ARGOS_INFERENCE_URL` for the API and workers. The service is ClusterIP
only, with ingress restricted to this release's pods in the same namespace.
Calls use an HMAC-derived bearer token based on the shared Django `SECRET_KEY`;
only that secret entry is passed to the inference pod, not database credentials.
Model weights are downloaded at image build and runtime is offline.

For development, build `Dockerfile.inference`, expose port 8001, and supply the
same `SECRET_KEY` as Django. The application's default inference URL is
`http://127.0.0.1:8001`. No Django database or Celery worker is needed in that
container. Keep request logging free of input text and vectors.

The inference pod reserves 6Gi and has a 12Gi limit. Other components still need
memory for scans, inventory, document parsing and cost calculations; moving
models out does not remove those workloads. Lowering memory requests changes
reservations, not actual usage.

# FinOps collection

Cost anomalies aggregate daily totals in one streaming query per organization;
only detected spikes require attribution/upsert queries. Missing baseline days
are not filled with zeros.

vSphere performance collection uses the existing connector, with at most 20 VMs
per SOAP request, a 60-second connection timeout, and progress saved per batch.
Inventory pagination reuses a connector-local snapshot for up to five minutes;
requesting page one refreshes it. Missing metrics, failed batches or truncated
inventory prevent automatic resolution of previous recommendations. A soft task
timeout marks the run failed; the hard limit is a final process safeguard.
