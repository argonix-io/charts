# Argonix API Helm chart

The current release pair is chart `0.5.0` with application images `0.5.0`.
Use `--version 0.5.0` for Helm and pin API, frontend, scanner and inference
images to `0.5.0` when overriding image tags. The English and French
self-hosted installation guides contain matching install and upgrade examples.

The migration for this release adds concurrent indexes for historical resource
identity resolution. Run the chart's migration job before serving the new API.

# Worker queues

`runtimeSummaryWorker.enabled` defaults to `true`. Its single worker consumes
`runtime-summary`, keeping hourly network dashboard preparation out of the general
queue. It uses the worker image. If disabled, the general worker consumes this
queue too; external Celery deployments must add a consumer explicitly. Apply
inventory migrations `0074`–`0076` before starting the updated API and workers. Existing
hourly summaries are rebuilt progressively; reads use exact raw data until ready.

`runtimeMaintenanceWorker.enabled` defaults to `true`. Its single worker
consumes `runtime-maintenance` for traffic compaction and raw observation
retention. This prevents short-lived compaction jobs from expiring behind
unrelated long tasks. If disabled, the general worker consumes the queue.

Enable `finopsWorker.enabled` to deploy a dedicated worker consuming `finops`.
With this option enabled, the general worker consumes only `celery`. When it is
disabled (the default), the general worker consumes both queues for compatibility.
Deploy the application, scanner and inference images with chart 0.2.0 together.

FinOps collection, allocation, optimization, anomaly detection and budget tasks
route to `finops`. Agent investigations and approved remediation retain the
general worker's larger memory budget. Monitor tasks and monitor alert evaluation
and delivery route to `monitors`; external alert ingestion and AI investigations
remain on their existing queues.

Routing applies to newly published messages. Existing messages in `celery` drain
there; do not purge them during rollout. Explicit queue overrides on custom
DatabaseScheduler entries take precedence over application routes.

Observed network-edge preparation also routes to `runtime-summary`. It dispatches
one complete hour per organization, newest hour first, with a 120-second soft
limit and 150-second hard limit. Disjoint hours can run concurrently; overlapping
buckets share a writer lock. SQL timeouts are local to each transaction, without
changing the shared database server. Retention probes preserve oldest-first
ordering, allowing the existing organization/time index to serve continuation
checks. Default DNS retention is 24 hours (`dns_days=1`); raw flow/process and
sensor cursor retention remains 3 days, hourly edges 90 days.

The monitors worker defaults to `dnsConfig.options: [{name: ndots, value: "1"}]`,
reducing Kubernetes search expansions for dotted external targets while retaining
the search list for short service names. This is scoped to monitors pods. Set
`monitorsWorker.dnsConfig: null` to inherit the cluster DNS defaults. Kubernetes
documents pod DNS options [here](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-config).

The next API build reuses the TLS certificate of each fresh HTTP probe instead
of making a second DNS/TCP/TLS connection just to read its expiry. When transport
metadata is unavailable or the redirect changes origin, the separate certificate
probe remains the fallback. Immutable DNS/process ingestion uses PostgreSQL
`ON CONFLICT DO NOTHING RETURNING` to avoid pre-reading these large tables; batch
transactions and uniqueness constraints still preserve replay/rollback behavior.
These changes require the new API/worker image and no shared SQL configuration.

Datadog log search reports missing or inaccessible indexes explicitly as
`logs_indexes_unavailable`, rather than a successful empty result. These HTTP
400 failures are cached for five minutes per worker and credential/index selection
to avoid repeating an impossible query. Changing keys or the optional connector
`log_indexes` selection bypasses that cache; provider-side fixes are retried after
expiry. Configure accessible Logs indexes and application-key permissions in
Datadog. The connector cannot create missing indexes or grant itself access.

The dedicated FinOps worker defaults to one process, a 1Gi memory request and a
4Gi limit. Its 660-second shutdown grace accommodates the ten-minute cost-sync
and vSphere task limits. Other FinOps tasks can have different execution limits.
Size requests and limits against peak measurements after rollout.

# Dedicated AI Code Hunter worker

The AI tab is available on Code projects without selecting a scanner engine.
Chart 0.2.5 deploys `hunterWorker` by default so its queue has a consumer.
`security.run_code_analysis` stays on `scanner`;
`security.run_code_hunter` consumes only `code-hunter`. Resume and
recovery also dispatch AI batches to that dedicated queue. Schedule dispatch and
recovery coordination remain on the general queue. There is no AI fallback to a
scanner or general worker, so without a Hunter consumer AI batches remain queued.

Image precedence is `hunterWorker.image` when its repository is configured,
then a configured `scannerWorker.image`, then the standard API `image`. Both
`Dockerfile.django` and `Dockerfile.scanner` ship Git, the organization LLM SDKs
and `argonix.scanner_celery` under `/app`. Deploy the selected image from the same
revision as the application. A custom image must preserve that working directory,
readable application files and these runtime dependencies. The startup probe
checks them and the writable temporary volumes. The worker loads no local model
weights and requires no GPU. `hunterWorker.enabled=false` is still supported,
but an external `code-hunter` consumer is then needed for AI reviews to progress.

Defaults are one replica, concurrency one, prefetch one, a 250m CPU/1Gi memory
request and a one CPU/2Gi memory limit. This reservation is added by the default
deployment even before a user starts an AI review. Writable checkout storage is an ephemeral
5Gi volume; `/tmp` is an additional 1Gi volume. The filesystem otherwise stays
read-only and the worker runs as UID/GID 10001 without Linux capabilities or an
automounted Kubernetes service account token. Override resources based on
repository size and measured peak use. Increasing replicas or concurrency also
increases simultaneous hosted LLM requests and potential cost.

The 1020-second shutdown grace accommodates the Hunter task's 900-second soft
and 960-second hard limits, including checkout. Celery receives SIGTERM directly
and can finish the active batch. A killed batch can be redelivered against the
same checkpoint; already completed batches are preserved. Deployment does not
clear messages from any queue.

`hunterWorker.networkPolicy.enabled` is optional and disabled by default. When
enabled, the policy denies ingress and allows DNS plus public HTTPS for Git and
hosted LLM endpoints. Unlike the scanner policy, it does not implicitly allow
all private networks. Set `privateEgressCidrs` to the required private DB, broker,
Git or LLM destinations; `privateEgressPorts` defaults to TCP 443, 5432 and 6379.
Use `extraEgress` for namespace/pod selectors, TLS broker ports or other private
LLM/artifact storage endpoints. CNI handling of service address translation must
be considered when choosing CIDRs; a namespace/pod selector is often appropriate
for in-cluster DB and broker pods. Other applicable policies can add permissions.

The optional `hunterWorker.existingSecret` allows a restricted environment. It
must retain the database and broker connection settings, shared `SECRET_KEY`
and any required artifact-storage credentials. Organization LLM credentials are
read through the existing organization settings, not copied into chart values.

Validate the chart locally without accessing a cluster:

```sh
helm dependency build charts/api
python -m unittest discover -s charts/api/tests -q
helm lint charts/api
```

# Dedicated inference (breaking change in 0.2.0)

All embedding and reranking calls use the internal `-inference:8001` service.
There is no local backend or local fallback. The API and workers no longer ship
model weights, PyTorch, Transformers or ONNX Runtime. The dedicated image loads
Qwen3-Embedding-0.6B and Qwen3-Reranker-0.6B once, using native Transformers
on CPU. The embedding output remains 1024-dimensional and normalized. Retrieval
queries receive a task instruction; documents and finding comparisons use
unprompted encoding. Embeddings use last-token pooling. Reranking scores the
model's yes/no logits and is enabled in the RAG pipeline.

The Qwen switch clears all four sets of persisted embeddings in migration 0138.
Stop old writers for this direct cutover. The chart's `embeddingBackfill` Job
rebuilds chunks, findings, tickets and ignores, resuming committed batches after
failure. Wait for its completion before resuming workloads. See
[the deployment and rebuild procedure](../../docs/features/qwen3-embeddings.md).

The service always has one replica/process. Inference runs serially in batches
of eight, with at most eight pending/active requests; saturation returns HTTP
503. Clients have bounded timeouts and do not retry automatically. During a
service restart, RAG requests can fail until the models are ready. The existing
retrieval behaviour on reranking failure (returning unreranked passages) remains.

Helm sets `ARGOS_INFERENCE_URL` for the API and workers. The service is ClusterIP
only, with ingress restricted to this release's pods in the same namespace.
Calls use an HMAC-derived bearer token based on the shared Django `SECRET_KEY`;
only that secret entry is passed to the inference pod, not database credentials.
Model weights are downloaded at image build and runtime is offline.

For development, build `Dockerfile.inference`, expose port 8001, and supply the
same `SECRET_KEY` as Django. The application's default inference URL is
`http://127.0.0.1:8001`. No Django database or Celery worker is needed in that
container. Keep request logging free of input text and vectors.

The inference pod reserves 6Gi and has a 12Gi limit. Other components still need
memory for scans, inventory, document parsing and cost calculations; moving
models out does not remove those workloads. Lowering memory requests changes
reservations, not actual usage.

# FinOps collection

Cost anomalies aggregate daily totals in one streaming query per organization;
only detected spikes require attribution/upsert queries. Missing baseline days
are not filled with zeros.

vSphere performance collection uses the existing connector, with at most 20 VMs
per SOAP request, a 60-second connection timeout, and progress saved per batch.
Inventory pagination reuses a connector-local snapshot for up to five minutes;
requesting page one refreshes it. Missing metrics, failed batches or truncated
inventory prevent automatic resolution of previous recommendations. A soft task
timeout marks the run failed; the hard limit is a final process safeguard.
