{{/*
Expand the name of the chart.
*/}}
{{- define "argonix-beat.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "argonix-beat.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "argonix-beat.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "argonix-beat.labels" -}}
helm.sh/chart: {{ include "argonix-beat.chart" . }}
{{ include "argonix-beat.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "argonix-beat.selectorLabels" -}}
app.kubernetes.io/name: {{ include "argonix-beat.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "argonix-beat.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "argonix-beat.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Image helper
*/}}
{{- define "argonix-beat.image" -}}
{{- $registry := .Values.global.imageRegistry | default .Values.image.registry -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry .Values.image.repository $tag -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository $tag -}}
{{- end -}}
{{- end }}

{{/*
ConfigMap ref name
*/}}
{{- define "argonix-beat.configMapRef" -}}
{{- .Values.configMapRef | default (include "argonix-beat.fullname" .) -}}
{{- end }}

{{/*
Secret ref name
*/}}
{{- define "argonix-beat.secretRef" -}}
{{- .Values.secretRef | default (include "argonix-beat.secretName" .) -}}
{{- end }}

{{/*
Secret name (handles existingSecret)
*/}}
{{- define "argonix-beat.secretName" -}}
{{- if .Values.secrets.existingSecret -}}
{{- .Values.secrets.existingSecret -}}
{{- else -}}
{{- include "argonix-beat.fullname" . -}}
{{- end -}}
{{- end }}
