{{/*
Expand the name of the chart.
*/}}
{{- define "argonix.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "argonix.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "argonix.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "argonix.labels" -}}
helm.sh/chart: {{ include "argonix.chart" . }}
{{ include "argonix.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "argonix.selectorLabels" -}}
app.kubernetes.io/name: {{ include "argonix.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "argonix.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "argonix.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Image helper - returns full image reference
*/}}
{{- define "argonix.image" -}}
{{- $registry := .Values.global.imageRegistry | default .Values.image.registry -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry .Values.image.repository $tag -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository $tag -}}
{{- end -}}
{{- end }}

{{/*
Worker image helper
*/}}
{{- define "argonix.workerImage" -}}
{{- if .Values.worker.image.repository -}}
  {{- $registry := .Values.worker.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
  {{- $tag := .Values.worker.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if $registry -}}
  {{- printf "%s/%s:%s" $registry .Values.worker.image.repository $tag -}}
  {{- else -}}
  {{- printf "%s:%s" .Values.worker.image.repository $tag -}}
  {{- end -}}
{{- else -}}
  {{- include "argonix.image" . -}}
{{- end -}}
{{- end }}

{{/*
Workflow worker image helper
*/}}
{{- define "argonix.workflowWorkerImage" -}}
{{- if .Values.workflowWorker.image.repository -}}
  {{- $registry := .Values.workflowWorker.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
  {{- $tag := .Values.workflowWorker.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if $registry -}}
  {{- printf "%s/%s:%s" $registry .Values.workflowWorker.image.repository $tag -}}
  {{- else -}}
  {{- printf "%s:%s" .Values.workflowWorker.image.repository $tag -}}
  {{- end -}}
{{- else -}}
  {{- include "argonix.image" . -}}
{{- end -}}
{{- end }}

{{/*
KB Worker image helper
*/}}
{{- define "argonix.kbWorkerImage" -}}
{{- if .Values.kbWorker.image.repository -}}
  {{- $registry := .Values.kbWorker.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
  {{- $tag := .Values.kbWorker.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if $registry -}}
  {{- printf "%s/%s:%s" $registry .Values.kbWorker.image.repository $tag -}}
  {{- else -}}
  {{- printf "%s:%s" .Values.kbWorker.image.repository $tag -}}
  {{- end -}}
{{- else -}}
  {{- include "argonix.image" . -}}
{{- end -}}
{{- end }}

{{/*
Monitors worker image helper
*/}}
{{- define "argonix.monitorsWorkerImage" -}}
{{- if .Values.monitorsWorker.image.repository -}}
  {{- $registry := .Values.monitorsWorker.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
  {{- $tag := .Values.monitorsWorker.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if $registry -}}
  {{- printf "%s/%s:%s" $registry .Values.monitorsWorker.image.repository $tag -}}
  {{- else -}}
  {{- printf "%s:%s" .Values.monitorsWorker.image.repository $tag -}}
  {{- end -}}
{{- else -}}
  {{- include "argonix.image" . -}}
{{- end -}}
{{- end }}

{{/*
Scanner worker image helper
*/}}
{{- define "argonix.scannerWorkerImage" -}}
{{- $repository := required "scannerWorker.image.repository is required when scannerWorker.enabled=true; use the image built from Dockerfile.scanner" .Values.scannerWorker.image.repository -}}
  {{- $registry := .Values.scannerWorker.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
  {{- $tag := .Values.scannerWorker.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if $registry -}}
  {{- printf "%s/%s:%s" $registry $repository $tag -}}
  {{- else -}}
  {{- printf "%s:%s" $repository $tag -}}
  {{- end -}}
{{- end }}

{{/*
Beat image helper
*/}}
{{- define "argonix.beatImage" -}}
{{- if .Values.beat.image.repository -}}
  {{- $registry := .Values.beat.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
  {{- $tag := .Values.beat.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
  {{- if $registry -}}
  {{- printf "%s/%s:%s" $registry .Values.beat.image.repository $tag -}}
  {{- else -}}
  {{- printf "%s:%s" .Values.beat.image.repository $tag -}}
  {{- end -}}
{{- else -}}
  {{- include "argonix.image" . -}}
{{- end -}}
{{- end }}

{{/*
Frontend image helper
*/}}
{{- define "argonix.frontendImage" -}}
{{- $registry := .Values.frontend.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
{{- $repository := .Values.frontend.image.repository | default (printf "%s-frontend" .Values.image.repository) -}}
{{- $tag := .Values.frontend.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end }}

{{/*
Landing image helper
*/}}
{{- define "argonix.landingImage" -}}
{{- $registry := .Values.landing.image.registry | default .Values.global.imageRegistry | default .Values.image.registry -}}
{{- $repository := .Values.landing.image.repository | default (printf "%s-landing" .Values.image.repository) -}}
{{- $tag := .Values.landing.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end }}

{{/*
Secret name helper
*/}}
{{- define "argonix.secretName" -}}
{{- if .Values.secrets.existingSecret -}}
{{- .Values.secrets.existingSecret -}}
{{- else -}}
{{- include "argonix.fullname" . -}}
{{- end -}}
{{- end }}
