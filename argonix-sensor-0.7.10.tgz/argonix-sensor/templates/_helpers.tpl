{{/* Cluster-scoped RBAC stays distinct across release namespaces and truncation. */}}
{{- define "argonixSensor.connectorRbacName" -}}
{{- $identity := printf "%s/%s/connector-trivy-read" .Release.Namespace .Release.Name -}}
{{- $prefix := printf "%s-%s-connector-trivy-read" .Release.Namespace .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- printf "%s-%s" $prefix (sha256sum $identity | trunc 12) -}}
{{- end -}}

{{- define "argonixSensor.connectorRbacLabels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" | quote }}
app.kubernetes.io/name: {{ .Chart.Name | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/component: connector-rbac
{{- end -}}
