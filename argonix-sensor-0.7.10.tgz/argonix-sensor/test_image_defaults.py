"""Exercise the wrapper against the packaged upstream dependency using Helm."""

import shutil
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

import yaml


CHART = Path(__file__).resolve().parent


def render(chart=CHART, *settings, values=None, release="argonix-sensor", namespace="default"):
    command = ["helm", "template", release, str(chart), "--namespace", namespace,
               "--set", "sensor.clusterName=ci",
               "--set", "tetragon.tetragon.nameOverride=tetragon"]
    for setting in settings:
        command.extend(["--set", setting])
    if values is not None:
        command.extend(["--values", str(values)])
    documents = [doc for doc in yaml.safe_load_all(
        subprocess.check_output(command, text=True)) if doc]
    identities = [(doc["kind"], doc["metadata"]["name"]) for doc in documents]
    if len(identities) != len(set(identities)):
        raise AssertionError("duplicate resources in sensor chart")
    return documents


def images(documents):
    daemonsets = [doc for doc in documents if doc["kind"] == "DaemonSet"]
    if len(daemonsets) != 1:
        raise AssertionError(f"expected one DaemonSet, got {len(daemonsets)}")
    return {item["name"]: item["image"] for item in
            daemonsets[0]["spec"]["template"]["spec"]["containers"]}


class SensorImageDefaults(unittest.TestCase):
    def test_defaults_and_example_values(self):
        version = str(yaml.safe_load((CHART / "Chart.yaml").read_text())["appVersion"])
        for values in (None, CHART.parents[1] / "docs/examples/sensor-values.yaml"):
            with self.subTest(values=values):
                settings = () if values is None else ("--values", str(values))
                output = subprocess.check_output([
                    "helm", "template", "argonix-sensor", str(CHART),
                    "--set", "sensor.clusterName=ci", *settings], text=True)
                self.assertEqual(images([doc for doc in yaml.safe_load_all(output) if doc]), {
                    "tetragon": f"ghcr.io/argonix-io/argonix-api-tetragon:{version}",
                    "export-stdout": f"ghcr.io/argonix-io/argonix-api-sensor:{version}",
                })

    def test_new_app_version_independent_of_chart_and_upstream_versions(self):
        with tempfile.TemporaryDirectory() as directory:
            chart = Path(directory) / "sensor"
            shutil.copytree(CHART, chart)
            metadata = yaml.safe_load((chart / "Chart.yaml").read_text())
            metadata.update(version="9.8.7", appVersion="9.8.6")
            (chart / "Chart.yaml").write_text(yaml.safe_dump(metadata))
            self.assertEqual(images(render(chart)), {
                "tetragon": "ghcr.io/argonix-io/argonix-api-tetragon:9.8.6",
                "export-stdout": "ghcr.io/argonix-io/argonix-api-sensor:9.8.6",
            })

    def test_custom_repositories_and_tags(self):
        self.assertEqual(images(render(CHART,
            "tetragon.tetragon.image.repository=registry.example/tetragon",
            "tetragon.tetragon.image.tag=agent-test",
            "tetragon.export.stdout.image.repository=registry.example/sensor",
            "tetragon.export.stdout.image.tag=collector-test")), {
                "tetragon": "registry.example/tetragon:agent-test",
                "export-stdout": "registry.example/sensor:collector-test",
            })

    def test_legacy_overrides_take_precedence(self):
        self.assertEqual(images(render(CHART,
            "tetragon.tetragon.image.override=registry.example/tetragon@sha256:123",
            "tetragon.tetragon.image.tag=ignored",
            "tetragon.export.stdout.image.override=registry.example/sensor:legacy",
            "tetragon.export.stdout.image.tag=ignored")), {
                "tetragon": "registry.example/tetragon@sha256:123",
                "export-stdout": "registry.example/sensor:legacy",
            })

    def test_agent_config_and_optional_monitoring(self):
        documents = render(CHART, "tetragon.tetragon.prometheus.serviceMonitor.enabled=true")
        self.assertTrue(any(doc["kind"] == "ConfigMap" and
                            doc["metadata"]["name"] == "tetragon-config" for doc in documents))
        self.assertTrue(any(doc["kind"] == "Service" and
                            doc["metadata"]["name"] == "tetragon" for doc in documents))
        self.assertTrue(any(doc["kind"] == "ServiceMonitor" for doc in documents))

    def test_agent_role_can_read_gateway_discovery_without_write_access(self):
        documents = render()
        role = next(doc for doc in documents if doc["kind"] == "ClusterRole" and
                    doc["metadata"]["name"].endswith("-gateway-read"))
        self.assertEqual(role["rules"], [{"apiGroups": ["gateway.networking.k8s.io"],
            "resources": ["gateways", "httproutes"], "verbs": ["get", "list", "watch"]}])
        binding = next(doc for doc in documents if doc["kind"] == "ClusterRoleBinding"
                       and doc["metadata"]["name"] == role["metadata"]["name"])
        agent = next(doc for doc in documents if doc["kind"] == "DaemonSet")
        self.assertEqual(binding["roleRef"]["name"], role["metadata"]["name"])
        self.assertEqual(binding["subjects"][0]["name"],
                         agent["spec"]["template"]["spec"]["serviceAccountName"])

    def test_external_service_account_keeps_external_rbac_ownership(self):
        documents = render(CHART, "tetragon.serviceAccount.create=false",
                           "tetragon.serviceAccount.name=external-sensor")
        self.assertFalse(any(doc["kind"] == "ClusterRole" and
                             doc["metadata"]["name"].endswith("-gateway-read")
                             for doc in documents))

    def test_export_exclusions_preserve_separate_upstream_filters(self):
        documents = render()
        config = next(doc for doc in documents if doc["kind"] == "ConfigMap" and
                      doc["metadata"]["name"] == "tetragon-config")
        filters = [json.loads(line) for line in config["data"]["export-denylist"].splitlines()]
        self.assertIn({"health_check": True}, filters)
        namespace_filter = next(item for item in filters if "namespace" in item)
        values = yaml.safe_load((CHART / "values.yaml").read_text())
        self.assertEqual(namespace_filter, {"namespace": values["sensor"]["excludeNamespaces"]})

    def test_empty_export_exclusions_keep_custom_filter(self):
        with tempfile.TemporaryDirectory() as directory:
            values = Path(directory) / "values.yaml"
            values.write_text(yaml.safe_dump({
                "sensor": {"excludeNamespaces": []},
                "tetragon": {"tetragon": {"exportDenyList":
                    json.dumps({"event_set": ["PROCESS_EXEC"]})}},
            }))
            documents = render(values=values)
        config = next(doc for doc in documents if doc["kind"] == "ConfigMap" and
                      doc["metadata"]["name"] == "tetragon-config")
        self.assertEqual(json.loads(config["data"]["export-denylist"]),
                         {"event_set": ["PROCESS_EXEC"]})


class ConnectorRbac(unittest.TestCase):
    @staticmethod
    def grants(documents):
        return [doc for doc in documents if doc.get("metadata", {}).get(
            "labels", {}).get("app.kubernetes.io/component") == "connector-rbac"]

    def render_accounts(self, accounts, **kwargs):
        with tempfile.TemporaryDirectory() as directory:
            values = Path(directory) / "values.yaml"
            values.write_text(yaml.safe_dump({"connectorRbac": {
                "enabled": True, "serviceAccounts": accounts}}))
            return render(values=values, **kwargs)

    def test_default_installs_no_connector_grant(self):
        self.assertEqual(self.grants(render()), [])

    def test_only_explicit_accounts_receive_exact_trivy_read_grant(self):
        accounts = [{"namespace": "platform", "name": "platform"},
                    {"namespace": "inventory", "name": "connector.reader"}]
        documents = self.render_accounts(accounts)
        grants = self.grants(documents)
        self.assertEqual(len(grants), 2)
        role = next(doc for doc in grants if doc["kind"] == "ClusterRole")
        binding = next(doc for doc in grants if doc["kind"] == "ClusterRoleBinding")
        self.assertEqual(role["rules"], [{
            "apiGroups": ["aquasecurity.github.io"],
            "resources": ["vulnerabilityreports", "exposedsecretreports"],
            "verbs": ["get", "list", "watch"],
        }])
        self.assertEqual(binding["roleRef"], {
            "apiGroup": "rbac.authorization.k8s.io", "kind": "ClusterRole",
            "name": role["metadata"]["name"],
        })
        self.assertEqual(binding["metadata"]["name"], role["metadata"]["name"])
        self.assertEqual(binding["subjects"], [
            {"kind": "ServiceAccount", **account} for account in accounts])
        self.assertNotIn("argonix:platform:admin", role["metadata"]["name"])
        agent = next(doc for doc in documents if doc["kind"] == "DaemonSet")
        agent_account = agent["spec"]["template"]["spec"]["serviceAccountName"]
        self.assertNotIn(agent_account, [subject["name"] for subject in binding["subjects"]])
        # Enabling this option adds only a role and binding; no account/token resources.
        baseline = {(doc["kind"], doc["metadata"]["name"]) for doc in render()}
        enabled = {(doc["kind"], doc["metadata"]["name"]) for doc in documents}
        self.assertEqual(enabled - baseline, {
            ("ClusterRole", role["metadata"]["name"]),
            ("ClusterRoleBinding", role["metadata"]["name"]),
        })

    def test_names_are_short_stable_and_distinct_across_namespaces(self):
        accounts = [{"namespace": "argonix", "name": "argonix-connector"}]
        options = [
            {"release": "r" * 53, "namespace": "n" * 63},
            {"release": "r" * 53, "namespace": "n" * 62 + "m"},
            {"release": "beta-gamma", "namespace": "alpha"},
            {"release": "gamma", "namespace": "alpha-beta"},
        ]
        names = [self.grants(self.render_accounts(accounts, **option))[0][
            "metadata"]["name"] for option in options]
        self.assertEqual(len(set(names)), len(names))
        for name in names:
            self.assertLessEqual(len(name), 63)
            self.assertRegex(name, r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?$")
        self.assertEqual(names[0], self.grants(self.render_accounts(
            accounts, **options[0]))[0]["metadata"]["name"])

    def test_invalid_accounts_fail_with_a_clear_field_error(self):
        invalid = [([], "serviceAccounts"),
                   ([{"name": "reader"}], "namespace"),
                   ([{"namespace": "argonix"}], "name"),
                   ([{"namespace": "Other", "name": "reader"}], "namespace"),
                   ([{"namespace": "n" * 64, "name": "reader"}], "namespace"),
                   ([{"namespace": "argonix", "name": "../admin"}], "name"),
                   ([{"namespace": "argonix", "name": "x" * 254}], "name"),
                   ([{"namespace": "argonix", "name": 123}], "name"),
                   ([{"namespace": "argonix", "name": "reader"}] * 2, "serviceAccounts")]
        for accounts, field in invalid:
            with self.subTest(accounts=accounts):
                with tempfile.TemporaryDirectory() as directory:
                    values = Path(directory) / "values.yaml"
                    values.write_text(yaml.safe_dump({"connectorRbac": {
                        "enabled": True, "serviceAccounts": accounts}}))
                    for flags in ([], ["--skip-schema-validation"]):
                        with self.subTest(flags=flags):
                            result = subprocess.run([
                                "helm", "template", "argonix-sensor", str(CHART),
                                "--set", "sensor.clusterName=ci", "--values", str(values),
                                *flags,
                            ], capture_output=True, text=True)
                            self.assertNotEqual(result.returncode, 0)
                            self.assertIn("connectorRbac", result.stderr)
                            self.assertIn(field, result.stderr)

    def test_enabled_requires_a_boolean_even_without_schema_validation(self):
        for enabled in ("false", "true"):
            with self.subTest(enabled=enabled), tempfile.TemporaryDirectory() as directory:
                values = Path(directory) / "values.yaml"
                values.write_text(yaml.safe_dump({"connectorRbac": {
                    "enabled": enabled,
                    "serviceAccounts": [{"namespace": "platform", "name": "platform"}],
                }}))
                result = subprocess.run([
                    "helm", "template", "argonix-sensor", str(CHART),
                    "--set", "sensor.clusterName=ci", "--values", str(values),
                    "--skip-schema-validation",
                ], capture_output=True, text=True)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn("connectorRbac.enabled must be a boolean", result.stderr)


if __name__ == "__main__":
    unittest.main()
