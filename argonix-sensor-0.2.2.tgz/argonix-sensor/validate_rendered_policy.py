"""Validate typed structures in the rendered Tetragon policy."""

import sys

import yaml


documents = [document for document in yaml.safe_load_all(sys.stdin) if document]
policy = next(
    document
    for document in documents
    if document.get("kind") == "TracingPolicy"
    and document.get("metadata", {}).get("name") == "argonix-network-connect"
)
file_probe = next(
    probe
    for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "security_file_open"
)
match_args = file_probe["selectors"][0]["matchArgs"]
if len(match_args) != 1 or not isinstance(match_args[0], dict):
    raise SystemExit("security_file_open must contain one typed matchArgs object")
values = match_args[0].get("values")
if not isinstance(values, list) or not values or not all(
    isinstance(value, str) for value in values
):
    raise SystemExit("security_file_open matchArgs.values must be a string list")

