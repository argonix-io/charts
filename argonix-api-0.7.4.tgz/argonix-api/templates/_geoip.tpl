{{/* Local Country database shared with a per-pod updater or mounted offline. */}}
{{- define "argonix.geoipProvider" -}}
{{- if .Values.geoip.provider -}}
{{- .Values.geoip.provider -}}
{{- else if or .Values.geoip.existingClaim .Values.geoip.updater.existingSecret -}}
maxmind
{{- else -}}
iplocate
{{- end -}}
{{- end -}}

{{- define "argonix.geoipValidate" -}}
{{- if .Values.geoip.enabled -}}
{{- $provider := include "argonix.geoipProvider" . -}}
{{- if not (has $provider (list "iplocate" "maxmind")) -}}
{{- fail "geoip.provider must be iplocate or maxmind (or empty for automatic selection)" -}}
{{- end -}}
{{- if and (eq $provider "maxmind") (not (has .Values.geoip.editionId (list "GeoLite2-Country" "GeoIP2-Country"))) -}}
{{- fail "geoip.editionId must be GeoLite2-Country or GeoIP2-Country" -}}
{{- end -}}
{{- if not .Values.geoip.existingClaim -}}
{{- if not .Values.geoip.updater.enabled -}}
{{- fail "geoip.enabled requires geoip.existingClaim or geoip.updater.enabled" -}}
{{- end -}}
{{- if eq $provider "maxmind" -}}
{{- $_ := required "geoip.updater.existingSecret is required for MaxMind database downloads" .Values.geoip.updater.existingSecret -}}
{{- else if and .Values.geoip.updater.url (not (hasPrefix "https://" .Values.geoip.updater.url)) -}}
{{- fail "geoip.updater.url must use HTTPS" -}}
{{- end -}}
{{- if or (not (regexMatch "^[0-9]+$" (toString .Values.geoip.updater.frequencyHours))) (lt (int .Values.geoip.updater.frequencyHours) 1) (gt (int .Values.geoip.updater.frequencyHours) 168) -}}
{{- fail "geoip.updater.frequencyHours must be between 1 and 168" -}}
{{- end -}}
{{- end -}}
{{- if or (not (regexMatch "^[0-9]+$" (toString .Values.geoip.maxAgeDays))) (lt (int .Values.geoip.maxAgeDays) 1) -}}
{{- fail "geoip.maxAgeDays must be positive" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "argonix.geoipDatabasePath" -}}
{{- if .Values.geoip.enabled -}}
{{- if eq (include "argonix.geoipProvider" .) "iplocate" -}}
/var/lib/argonix/geoip/ip-to-country.mmdb
{{- else -}}
{{- printf "/var/lib/argonix/geoip/%s.mmdb" .Values.geoip.editionId -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* Preserve operator security settings and make emptyDir writable non-root. */}}
{{- define "argonix.geoipPodSecurityContext" -}}
{{- $context := deepCopy (default (dict) .context) -}}
{{- if and .root.Values.geoip.enabled (not .root.Values.geoip.existingClaim) -}}
{{- if not (hasKey $context "fsGroup") -}}
{{- $_ := set $context "fsGroup" 65532 -}}
{{- end -}}
{{- end -}}
{{- with $context }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end -}}
{{- end -}}

{{- define "argonix.geoipVolumeMounts" -}}
{{- if .Values.geoip.enabled }}
volumeMounts:
  - name: geoip-country
    mountPath: /var/lib/argonix/geoip
    readOnly: true
{{- end -}}
{{- end -}}

{{- define "argonix.geoipVolumes" -}}
{{- if .Values.geoip.enabled }}
volumes:
  - name: geoip-country
    {{- if .Values.geoip.existingClaim }}
    persistentVolumeClaim:
      claimName: {{ .Values.geoip.existingClaim | quote }}
      readOnly: true
    {{- else }}
    emptyDir: {}
  - name: geoip-updater-tmp
    emptyDir: {}
    {{- end }}
{{- end -}}
{{- end -}}

{{- define "argonix.geoipUpdater" -}}
{{- $root := .root -}}
{{- $provider := include "argonix.geoipProvider" $root -}}
- name: {{ ternary "geoip-initial-download" "geoip-update" .once }}
  {{- if eq $provider "maxmind" }}
  image: {{ printf "%s:%s" $root.Values.geoip.updater.image.repository $root.Values.geoip.updater.image.tag | quote }}
  imagePullPolicy: {{ $root.Values.geoip.updater.image.pullPolicy }}
  {{- else }}
  image: {{ include "argonix.image" $root }}
  imagePullPolicy: {{ $root.Values.image.pullPolicy }}
  workingDir: /app
  command:
    - python
    - -m
    - argonix.security.geoip_update
    - --destination
    - {{ include "argonix.geoipDatabasePath" $root | quote }}
    {{- with $root.Values.geoip.updater.url }}
    - --url
    - {{ . | quote }}
    {{- end }}
    {{- if not .once }}
    - --interval-hours
    - {{ $root.Values.geoip.updater.frequencyHours | quote }}
    {{- end }}
  {{- end }}
  securityContext:
    runAsNonRoot: true
    runAsUser: 65532
    runAsGroup: 65532
    readOnlyRootFilesystem: true
    allowPrivilegeEscalation: false
    capabilities:
      drop: [ALL]
  {{- if eq $provider "maxmind" }}
  env:
    - name: GEOIPUPDATE_ACCOUNT_ID
      valueFrom:
        secretKeyRef:
          name: {{ $root.Values.geoip.updater.existingSecret | quote }}
          key: {{ $root.Values.geoip.updater.accountIdKey | quote }}
    - name: GEOIPUPDATE_LICENSE_KEY
      valueFrom:
        secretKeyRef:
          name: {{ $root.Values.geoip.updater.existingSecret | quote }}
          key: {{ $root.Values.geoip.updater.licenseKeyKey | quote }}
    - name: GEOIPUPDATE_EDITION_IDS
      value: {{ $root.Values.geoip.editionId | quote }}
    - name: GEOIPUPDATE_DB_DIR
      value: /var/lib/argonix/geoip
    - name: GEOIPUPDATE_FREQUENCY
      value: {{ ternary "0" ($root.Values.geoip.updater.frequencyHours | toString) .once | quote }}
  {{- end }}
  volumeMounts:
    - name: geoip-country
      mountPath: /var/lib/argonix/geoip
    - name: geoip-updater-tmp
      mountPath: /tmp
  resources:
    {{- toYaml $root.Values.geoip.updater.resources | nindent 4 }}
{{- end -}}

{{- define "argonix.geoipInitContainers" -}}
{{- if and .Values.geoip.enabled (not .Values.geoip.existingClaim) }}
initContainers:
  {{- include "argonix.geoipUpdater" (dict "root" . "once" true) | nindent 2 }}
{{- end -}}
{{- end -}}

{{- define "argonix.geoipSidecar" -}}
{{- if and .Values.geoip.enabled (not .Values.geoip.existingClaim) }}
{{- include "argonix.geoipUpdater" (dict "root" . "once" false) }}
{{- end -}}
{{- end -}}
