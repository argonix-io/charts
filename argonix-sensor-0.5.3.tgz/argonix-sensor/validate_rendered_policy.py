"""Validate typed structures in the rendered Tetragon policy."""

import sys

import yaml


documents = [document for document in yaml.safe_load_all(sys.stdin) if document]
policy = next(
    document
    for document in documents
    if document.get("kind") == "TracingPolicy"
    and document.get("metadata", {}).get("name") == "argonix-network-connect"
)
file_probe = next(
    probe
    for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "security_file_open"
)
match_args = file_probe["selectors"][0]["matchArgs"]
if len(match_args) != 1 or not isinstance(match_args[0], dict):
    raise SystemExit("security_file_open must contain one typed matchArgs object")
values = match_args[0].get("values")
if not isinstance(values, list) or not values or not all(
    isinstance(value, str) for value in values
):
    raise SystemExit("security_file_open matchArgs.values must be a string list")



dns_probe = next(
    probe
    for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "sys_sendto" and probe.get("syscall") is True
)
dns_args = {argument["index"]: argument for argument in dns_probe["args"]}
if dns_args.get(1) != {"index": 1, "type": "char_buf", "sizeArgIndex": 3}:
    raise SystemExit("sys_sendto must copy only the 1-based size-bounded user buffer")
if dns_args.get(4) != {"index": 4, "type": "sockaddr"}:
    raise SystemExit("sys_sendto must expose the destination sockaddr")
dns_match = dns_probe["selectors"][0]["matchArgs"][0]
if (
    dns_match.get("index") != 4
    or dns_match.get("operator") != "SPort"
    or dns_match.get("values") != ["53"]
):
    raise SystemExit("sys_sendto capture must be filtered to destination port 53")


recv_probe = next(
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "sys_recvfrom" and probe.get("return") is True
)
if recv_probe.get("returnArg") != {"index": 0, "type": "long"}:
    raise SystemExit("sys_recvfrom must declare its long syscall return value")
recv_args = {argument["index"]: argument for argument in recv_probe["args"]}
if recv_args.get(1) != {
    "index": 1, "type": "char_buf", "returnCopy": True, "sizeArgIndex": 3
}:
    raise SystemExit("sys_recvfrom DNS response buffer must be return-copied and bounded")

tcp_dns_send = next(
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "tcp_sendmsg"
    and any(argument.get("type") == "iov_iter" for argument in probe.get("args", []))
)
tcp_iter = next(
    argument for argument in tcp_dns_send["args"]
    if argument.get("type") == "iov_iter"
)
if tcp_iter.get("resolve") != "msg_iter" or tcp_iter.get("maxData") is not False:
    raise SystemExit("TCP DNS payload hook must resolve a capped msg_iter")
tcp_match = tcp_dns_send["selectors"][0]["matchArgs"][0]
if tcp_match.get("operator") != "DPort" or tcp_match.get("values") != ["53"]:
    raise SystemExit("TCP DNS payload hook must be filtered to destination port 53")

tcp_dns_recv = next(
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "tcp_recvmsg"
)
if tcp_dns_recv.get("returnArg") != {"index": 0, "type": "int"}:
    raise SystemExit("tcp_recvmsg must declare its int return value")

udp_dns_probes = [
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "udp_sendmsg"
    and any(argument.get("type") == "iov_iter" for argument in probe.get("args", []))
]
if len(udp_dns_probes) != 1:
    raise SystemExit("one bounded UDP DNS payload hook is required")
for probe in udp_dns_probes:
    iterator = next(
        argument for argument in probe["args"]
        if argument.get("type") == "iov_iter"
    )
    if iterator.get("resolve") != "msg_iter" or iterator.get("maxData") is not False:
        raise SystemExit(f"{probe['call']} must resolve a capped msg_iter")
    match = probe["selectors"][0]["matchArgs"][0]
    if match.get("operator") != "DPort" or match.get("values") != ["53"]:
        raise SystemExit(f"{probe['call']} must be filtered to destination port 53")
