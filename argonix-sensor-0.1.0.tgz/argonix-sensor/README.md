# Argonix Sensor Helm Chart

Provider-neutral runtime network sensor for Linux Kubernetes nodes. The chart
wraps the upstream Apache-2.0 Tetragon chart and replaces its JSON export
sidecar with the Python Argonix collector.

Supported Kubernetes environments include GKE, EKS, AKS, OVH Managed
Kubernetes, and on-premises clusters. The collector contains no cloud-provider
branching; `sensor.clusterName` is the stable identity chosen by the operator.

## Prerequisites

- Linux worker nodes with a Tetragon-supported kernel.
- Outbound HTTPS access from nodes to the Argonix API.
- An Argonix organization API key with `runtime-sensors:write` permission.
- Helm 3 or 4 and permission to install cluster-scoped Tetragon CRDs/RBAC.

Windows nodes are not selected by the upstream Tetragon DaemonSet and require
the future WFP/ETW sensor.

## Install

Create the credential without putting it in Helm values or shell history:

```bash
kubectl create namespace argonix-system
kubectl -n argonix-system create secret generic argonix-sensor-credentials \
  --from-literal=ARGONIX_API_KEY="$ARGONIX_API_KEY"
```

Install from the Argonix repository:

```bash
helm repo add argonix https://charts.argonix.io
helm repo update argonix
helm upgrade --install argonix-sensor argonix/argonix-sensor \
  --namespace argonix-system \
  --set sensor.apiBaseUrl=https://api.example.com/api/0.1 \
  --set sensor.clusterName=production-eu
```

The upstream Tetragon DaemonSet runs one pod per Linux node. Each pod contains:

1. the privileged upstream Tetragon container;
2. the non-root Argonix collector sidecar;
3. a node-local 256 MiB spool volume shared only inside the pod.

The node name comes from the Kubernetes Downward API. Each node enrolls
idempotently as `kubernetes/<clusterName>/<nodeName>`.

## Existing Tetragon installation

Do not install two Tetragon DaemonSets on the same nodes. The initial supported
path is to replace the existing release with this wrapper chart while preserving
the upstream Tetragon values. Sidecar-only attachment to an independently
managed Tetragon release is a later packaging mode.

## Verify

```bash
kubectl -n argonix-system get daemonset,pods -l app.kubernetes.io/part-of=tetragon
kubectl -n argonix-system logs -l app.kubernetes.io/name=tetragon \
  -c export-stdout --tail=50
```

## Linux VM mode

VMs use the same Python package and API contract but not this Helm chart:

1. install upstream Tetragon as a package/container or `systemd` service;
2. export JSON events to `/var/log/tetragon/tetragon.log`;
3. run `argonix-sensor` as a separate `systemd` service with platform
  `vm_linux`, `ARGONIX_NODE_NAME` set to a stable cloud instance/host identity,
  and the same scoped API key.

VM packaging is scheduled for Phase 4 of the runtime observability spec.