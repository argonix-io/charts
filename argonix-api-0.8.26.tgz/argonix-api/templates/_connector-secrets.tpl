{{- define "argonix.connectorSecretsName" -}}
{{- printf "%s-connector-secrets" (include "argonix.fullname" .) -}}
{{- end -}}

{{- define "argonix.connectorSecretsDirectory" -}}
/var/run/argonix-connector-secrets
{{- end -}}

{{- define "argonix.connectorSecretsChecksum" -}}
{{- with .Values.connectorSecrets.stores -}}
checksum/connector-secrets: {{ toJson . | sha256sum }}
{{- end -}}
{{- end -}}

{{- define "argonix.connectorSecretsEnvFrom" -}}
{{- if .Values.connectorSecrets.stores -}}
- configMapRef:
    name: {{ include "argonix.connectorSecretsName" . }}
{{- end -}}
{{- end -}}

{{- define "argonix.connectorSecretsMount" -}}
{{- if .Values.connectorSecrets.stores -}}
- name: connector-secrets
  mountPath: {{ include "argonix.connectorSecretsDirectory" . }}
  readOnly: true
{{- end -}}
{{- end -}}

{{- define "argonix.connectorSecretsVolume" -}}
{{- with .Values.connectorSecrets.stores -}}
- name: connector-secrets
  projected:
    defaultMode: 0444
    sources:
      {{- range $alias, $store := . }}
      - serviceAccountToken:
          audience: {{ $store.audience | default "argonix-vault" | quote }}
          expirationSeconds: 3600
          path: tokens/{{ $alias }}
      {{- with $store.caConfigMap }}
      - configMap:
          name: {{ . | quote }}
          items:
            - key: {{ $store.caKey | default "ca.crt" | quote }}
              path: ca/{{ $alias }}.pem
      {{- end }}
      {{- end }}
{{- end -}}
{{- end -}}

{{- define "argonix.connectorSecretsVolumeMounts" -}}
{{- if .Values.connectorSecrets.stores -}}
volumeMounts:
  {{- include "argonix.connectorSecretsMount" . | nindent 2 }}
{{- end -}}
{{- end -}}

{{- define "argonix.connectorSecretsVolumes" -}}
{{- if .Values.connectorSecrets.stores -}}
volumes:
  {{- include "argonix.connectorSecretsVolume" . | nindent 2 }}
{{- end -}}
{{- end -}}
