# Worker queues

Enable `finopsWorker.enabled` to deploy a dedicated worker consuming `finops`.
With this option enabled, the general worker consumes only `celery`. When it is
disabled (the default), the general worker consumes both queues for compatibility.
Deploy the application, scanner and inference images with chart 0.2.0 together.

FinOps collection, allocation, optimization, anomaly detection and budget tasks
route to `finops`. Agent investigations and approved remediation retain the
general worker's larger memory budget. Monitor tasks and monitor alert evaluation
and delivery route to `monitors`; external alert ingestion and AI investigations
remain on their existing queues.

Routing applies to newly published messages. Existing messages in `celery` drain
there; do not purge them during rollout. Explicit queue overrides on custom
DatabaseScheduler entries take precedence over application routes.

The dedicated FinOps worker defaults to one process, a 1Gi memory request and a
4Gi limit. Its 660-second shutdown grace accommodates the ten-minute cost-sync
and vSphere task limits. Other FinOps tasks can have different execution limits.
Size requests and limits against peak measurements after rollout.

# Dedicated inference (breaking change in 0.2.0)

All embedding and reranking calls use the internal `-inference:8001` service.
There is no local backend or local fallback. The API and workers no longer ship
model weights, PyTorch, Transformers or ONNX Runtime. The dedicated image loads
BGE-M3 and bge-reranker-v2-m3 once, using the existing ONNX calculation.

The service always has one replica/process. Inference runs serially in batches
of eight, with at most eight pending/active requests; saturation returns HTTP
503. Clients have bounded timeouts and do not retry automatically. During a
service restart, RAG requests can fail until the models are ready. The existing
retrieval behaviour on reranking failure (returning unreranked passages) remains.

Helm sets `ARGOS_INFERENCE_URL` for the API and workers. The service is ClusterIP
only, with ingress restricted to this release's pods in the same namespace.
Calls use an HMAC-derived bearer token based on the shared Django `SECRET_KEY`;
only that secret entry is passed to the inference pod, not database credentials.
Model weights are downloaded at image build and runtime is offline.

For development, build `Dockerfile.inference`, expose port 8001, and supply the
same `SECRET_KEY` as Django. The application's default inference URL is
`http://127.0.0.1:8001`. No Django database or Celery worker is needed in that
container. Keep request logging free of input text and vectors.

The inference pod reserves 6Gi and has a 12Gi limit. Other components still need
memory for scans, inventory, document parsing and cost calculations; moving
models out does not remove those workloads. Lowering memory requests changes
reservations, not actual usage.

# FinOps collection

Cost anomalies aggregate daily totals in one streaming query per organization;
only detected spikes require attribution/upsert queries. Missing baseline days
are not filled with zeros.

vSphere performance collection uses the existing connector, with at most 20 VMs
per SOAP request, a 60-second connection timeout, and progress saved per batch.
Inventory pagination reuses a connector-local snapshot for up to five minutes;
requesting page one refreshes it. Missing metrics, failed batches or truncated
inventory prevent automatic resolution of previous recommendations. A soft task
timeout marks the run failed; the hard limit is a final process safeguard.
