# Argonix Sensor Helm Chart

Provider-neutral runtime network sensor for Linux Kubernetes nodes. The chart
wraps the upstream Apache-2.0 Tetragon chart and replaces its JSON export
sidecar with the Python Argonix collector.

`Chart.yaml` `version` and `appVersion` are equal for each release and match
the `argonix-api-sensor` and patched Tetragon image tags. The current
chart `0.6.5` deploys collector/image `0.6.5` and a patched Tetragon 1.7.0
image tagged `0.6.5`. CI rejects either image tag if it differs from
`appVersion`. The Tetragon image fixes a startup panic on invalid UTF-8 in a
host process path or command line.

Supported Kubernetes environments include GKE, EKS, AKS, OVH Managed
Kubernetes, and on-premises clusters. The collector contains no cloud-provider
branching; `sensor.clusterName` is the stable identity chosen by the operator.

## Prerequisites

- Linux worker nodes with a Tetragon-supported kernel.
- Outbound HTTPS access from nodes to the Argonix API.
- An Argonix organization API key with `runtime-sensors:write` permission.
- Helm 3 or 4 and permission to install cluster-scoped Tetragon CRDs/RBAC.

Tetragon needs host networking, host paths, `/proc`, BPF maps, and a privileged
container. It cannot run in a namespace where Pod Security Admission enforces
`baseline` or `restricted`. Use a dedicated namespace such as
`argonix-sensor` with `enforce=privileged`; keep `warn` and `audit` at
`baseline` so policy drift remains visible. Do not weaken the namespace that
hosts the Argonix API.

Windows nodes are not selected by the upstream Tetragon DaemonSet and require
the future WFP/ETW sensor.

The chart enforces `kubernetes.io/os: linux` on the DaemonSet. This selector
must not be removed: Windows nodes do not expose Linux `/proc` or BPF host paths
and otherwise fail with `hostPath type check failed: /proc is not a directory`.

When upgrading across an event-contract compatibility fix, deploy the Argonix
API first and wait for existing sensors to drain their spools before upgrading
this chart. The current spool volume is an `emptyDir`: it survives collector
container restarts but not replacement of the DaemonSet pod.

If event production is faster than an older collector can drain, temporarily
set `sensor.tracingPolicy.enabled=false` on the current release. This removes
both default tracing policies without replacing the DaemonSet pods, so their
existing `emptyDir` spools remain available. Wait until every fresh sensor
reports `spool_events=0`, then upgrade the chart and re-enable the policy.

The collector aggregates repeated network, process, runtime-security and DNS
observations locally over 120-second windows. Candidate limits bound memory:
when a limit is reached, the sensor spools a complete cold signature and keeps
the busy signatures in memory. Every distinct destination IP remains in network
evidence. Repeated socket lifecycles keep connection counts and byte-counter
deltas across segments. The API accepts all segments with unique IDs, including
idempotent retries.

Open TCP lifecycle state and per-window socket metrics are independently capped
at 10,000 entries. `flow_state_evictions` and
`source_counter_overflow_events` in sensor health identify possible counter
inaccuracy when those bounds are reached. `spool_dropped_events` identifies
delivery loss and marks the sensor `degraded`. When the encrypted queue reaches
its 160 MiB payload limit or an observation ages beyond 24 hours, it deletes
the oldest queued observations and emits `sensor_spool.events_dropped` at ERROR
level with age/capacity counts. The 256 MiB `emptyDir` leaves room for SQLite
overhead. A sequence-loss declaration lets the API resume ingesting the
remaining observations; the API logs `runtime_ingest.sensor_sequence_loss` and
also logs `runtime_sensor.spool_loss` when the heartbeat loss counter rises.
Alert on either log event and on increasing `spool_dropped_events`; logs alone
do not send a notification. The heartbeat also reports `spool_bytes` and
`spool_limit_bytes`, and marks the sensor degraded at 70% utilization. Raw observations and boot cursors
are retained for 7 days; compact hourly edges are retained for 365 days. On
`SIGTERM`, the collector flushes the partial window to its encrypted spool and
gives the sender a bounded drain period before exiting.

Traffic-rate metrics use a separate aggregation path. Every 120-second window emits a
workload total and an external-egress total when applicable. Destination detail
uses a five-minute window and emits up to 50 candidate destinations per sensor;
remaining bytes and connections are counted in labelled aggregate rows. This
limit applies only to traffic metrics, not to per-IP security evidence. Stable
per-sensor window offsets spread writes over time. `sensor.maxTrafficScopes`
and `sensor.maxTrafficDestinationCandidates` bound in-memory segment sizes.
The API merges segments of the same measurement window before calculating
rates. Detail metrics are rolled up after two days; longer-lived hourly and
daily aggregates remain available.

The displayed rate is calculated from the byte count requested by application
send calls (`tcp_sendmsg` and `udp_sendmsg`). It is suitable for detecting large
external transfers and relative spikes, but it is deliberately labelled
**partial**: it is not an interface counter, does not include protocol overhead,
does not prove successful delivery, and does not currently measure received
payload throughput. No payload content is collected.

The collector drains one batch every five seconds, with a stable per-sensor
offset, while the spool is non-empty and returns to `sensor.flushSeconds` when
idle. A queue of 5,000 events, any spool drop, or a counter-state overflow marks
the sensor `degraded`. `sensor.sampleRate` must be `1.0`; startup rejects
sampling because it would bias security evidence.

## Install

Create and label the dedicated namespace. Put the scoped API key in a local
file outside the repository, restrict its permissions, then create the Secret
without putting the key in Helm values:

```bash
kubectl create namespace argonix-sensor
kubectl label namespace argonix-sensor \
  pod-security.kubernetes.io/enforce=privileged \
  pod-security.kubernetes.io/enforce-version=latest \
  pod-security.kubernetes.io/warn=baseline \
  pod-security.kubernetes.io/warn-version=latest \
  pod-security.kubernetes.io/audit=baseline \
  pod-security.kubernetes.io/audit-version=latest
kubectl -n argonix-sensor create secret generic argonix-sensor-credentials \
  --from-file=ARGONIX_API_KEY=./argonix-sensor-api-key
```

Install from the Argonix repository:

Save this example as `sensor-values.yaml` (also in
`docs/examples/sensor-values.yaml`), adapting the API URL and stable cluster
name to your environment. Keep the API key in the Secret created above, not in
`sensor.apiKey`:

```yaml
sensor:
  apiBaseUrl: "https://argonix-api.platform.isoftcloud.cloud/api/0.1"
  clusterName: "platform"
  flushSeconds: 10
  sampleRate: 1.0
  tracingPolicy:
    enabled: true

# Chart 0.6.0: keep Tetragon's ConfigMap name distinct from the collector's.
tetragon:
  tetragon:
    nameOverride: tetragon
    image:
      override: ghcr.io/argonix-io/argonix-api-tetragon:0.6.5
  export:
    stdout:
      image:
        override: ghcr.io/argonix-io/argonix-api-sensor:0.6.5
```

```bash
helm repo add argonix https://charts.argonix.io
helm repo update argonix
helm search repo argonix/argonix-sensor --versions
helm upgrade --install argonix-sensor argonix/argonix-sensor \
  --namespace argonix-sensor \
  --version 0.6.5 \
  --values sensor-values.yaml \
  --wait --timeout 15m
```

For an upgrade, use the same values file and chart `0.6.5`. Replace older
`tetragon.export.stdout.image.override` and `tetragon.tetragon.image.override`
values in Argo CD with the two images shown above; values supplied by Argo CD
take precedence over chart defaults. Verify the `export-stdout` collector and
`tetragon` containers both run image tag `0.6.5` after the DaemonSet rolls out.

### Argo CD namespace configuration

When Argo CD owns namespace creation, leave `namespace.create=false`, keep
`CreateNamespace=true`, set `spec.destination.namespace=argonix-sensor`, and
configure:

```yaml
managedNamespaceMetadata:
  labels:
    pod-security.kubernetes.io/enforce: privileged
    pod-security.kubernetes.io/enforce-version: latest
    pod-security.kubernetes.io/warn: baseline
    pod-security.kubernetes.io/warn-version: latest
    pod-security.kubernetes.io/audit: baseline
    pod-security.kubernetes.io/audit-version: latest
```

The Argo CD `AppProject` must also permit the cluster-scoped policy resource:

```yaml
spec:
  clusterResourceWhitelist:
    - group: cilium.io
      kind: TracingPolicy
```

Without this entry Argo reports the policy as `Missing` and logs
`resource cilium.io:TracingPolicy is not permitted in project`. The CRD may
already exist; this is an AppProject authorization failure, not a CRD discovery
failure.

For a GitOps controller that does not manage namespace metadata, set
`namespace.create=true` so the chart renders the dedicated Namespace resource.

### CRDs and default tracing policies

The standalone mode installs Tetragon CRDs and separate Argonix network and
runtime security policies:

```yaml
tetragon:
  crds:
    installMethod: helm
sensor:
  tracingPolicy:
    enabled: true
    securityEnabled: true
    excludeKubeletSelfAccess: true
```

If an existing Tetragon installation owns the CRDs, use
`tetragon.crds.installMethod=none`. Setting
`sensor.tracingPolicy.enabled=false` removes both default policies and their
observations. During a diagnosed security hook incompatibility,
`sensor.tracingPolicy.securityEnabled=false` removes only the runtime security
policy; this reduces security coverage while keeping TCP/UDP and DNS hooks.
`sensor.tracingPolicy.excludeKubeletSelfAccess=true` filters kubelet's own
opens under `/var/lib/kubelet` in Tetragon. Opens by other binaries, including
access to pod secret volumes, remain visible. Set it to `false` if kubelet's
own file access is required as security evidence on a particular cluster.
Routine kubelet volume opens from other binaries are counted per volume type
over the 120-second observation window; secret and token paths stay exact and
high-severity observations bypass the window. Traffic totals remain exact over
120 seconds. Destination details use a bounded five-minute candidate set and
the rest are summed in explicit "Other destinations" rows; the sensor reports
the summarized count in its heartbeat. The 10-second sender poll also carries
heartbeats and policy control, so the longer observation window does not delay
those operations.
`maxEventsPerWindow` is retained for compatibility; it is a minimum candidate
capacity, not a hard cap on DNS or security evidence. When a normal flow or
process candidate set fills, one cold candidate is emitted and frequent
signatures continue accumulating instead of flushing the entire set.
The collector checks Tetragon's loaded policy states at each heartbeat. A
missing or failed network policy marks network and DNS coverage unavailable; a
missing or failed security policy marks runtime security coverage unavailable.
An unreachable policy status API marks coverage unknown and the sensor degraded.
Both policies carry Argo CD first-sync annotations so a CRD discovery delay
does not fail dry-run reconciliation.

The upstream Tetragon DaemonSet runs one pod per Linux node. Each pod contains:

1. the privileged upstream Tetragon container;
2. the non-root Argonix collector sidecar;
3. a node-local 256 MiB spool volume shared only inside the pod.

The node name comes from the Kubernetes Downward API. Each node enrolls
idempotently as `kubernetes/<clusterName>/<nodeName>`.

Spool payloads are encrypted with Fernet before SQLite persistence. Add an
independent `ARGONIX_SPOOL_KEY` entry to `argonix-sensor-credentials` when
possible. Without it, version 0.6.0 derives the encryption key from the scoped
API key; drain the spool before rotating that API key.

## Dynamic forbidden-command enforcement

Argonix command policies are pulled by every compatible sensor every
`sensor.policyPollSeconds` seconds (15 seconds by default). The collector calls
Tetragon's local `FineGuidanceSensors` gRPC API to add or delete the policy
without restarting either container. A deployment is acknowledged as applied
only after Tetragon confirms the RPC.

An enforced match posts bounded process metadata before sending SIGKILL. The
event contains the exact executable, parent, UID, policy, node and, where
available, Kubernetes namespace/pod/container/workload. It contains no process
memory, stdin, stdout or file content. The API turns confirmed kills into the
managed high-severity threat `Argonix Runtime · Forbidden command killed`;
existing `threat_detected` alert rules deliver it to the organization's
configured notification channels.

The Tetragon gRPC endpoint stays pod-local by default at
`127.0.0.1:54321`. Do not expose it outside the pod or host.

## Existing Tetragon installation

Do not install two Tetragon DaemonSets on the same nodes. The initial supported
path is to replace the existing release with this wrapper chart while preserving
the upstream Tetragon values. Sidecar-only attachment to an independently
managed Tetragon release is a later packaging mode.

## Verify

```bash
kubectl -n argonix-sensor rollout status daemonset/tetragon --timeout=10m
kubectl -n argonix-sensor get daemonset,pods -l app.kubernetes.io/instance=argonix-sensor
kubectl -n argonix-sensor logs daemonset/tetragon -c export-stdout --tail=50
kubectl get tracingpolicy argonix-network-connect
kubectl get tracingpolicy argonix-runtime-security
```

## Optional mTLS

The collector always requires its scoped Argonix API key. To additionally
authenticate the node at the TLS layer, create the optional fixed-name Secret:

```bash
kubectl -n argonix-sensor create secret tls argonix-sensor-mtls \
  --cert=node-client.crt \
  --key=node-client.key
```

The API ingress or service mesh must validate the client certificate against
the organization CA before forwarding the request to Django. If the Secret is
absent, the collector uses ordinary server-authenticated HTTPS. Automatic
certificate issuance and rotation are not part of version 0.6.0.

## Linux VM mode

VMs use the same Python package and API contract but not this Helm chart:

1. install upstream Tetragon as a package/container or `systemd` service;
   keep its gRPC API reachable only on `127.0.0.1:54321`;
2. export JSON events to `/var/log/tetragon/tetragon.log`;
3. run `argonix-sensor` as a separate `systemd` service with platform
  `vm_linux`, `ARGONIX_NODE_NAME` set to a stable cloud instance/host identity,
  and the same scoped API key.

Build or download the wheel, then install the hardened service:

```bash
sudo sensor/systemd/install.sh dist/argonix_sensor-0.6.5-py3-none-any.whl
sudo editor /etc/argonix-sensor/sensor.env
sudo systemctl start argonix-sensor
sudo systemctl status argonix-sensor
```

The collector runs unprivileged. Only upstream Tetragon needs kernel/eBPF
privileges. The service can read `/var/log/tetragon` and write only its private
state directory.
