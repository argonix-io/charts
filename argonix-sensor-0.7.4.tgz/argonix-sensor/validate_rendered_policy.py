"""Validate rendered sensor storage, Tetragon policies and bounded DNS hooks."""

import argparse
import json
import sys
from decimal import Decimal
from pathlib import Path

import yaml


parser = argparse.ArgumentParser()
parser.add_argument(
    "--mode", choices=("default", "network-only", "disabled"), default="default"
)
parser.add_argument("--check-standalone", action="store_true")
parser.add_argument("--allow-kubelet-self-access", action="store_true")
args = parser.parse_args()
if args.check_standalone and args.mode != "default":
    parser.error("standalone parity requires the default render")
if args.check_standalone and args.allow_kubelet_self_access:
    parser.error("standalone parity requires the default kubelet filter")
documents = [document for document in yaml.safe_load_all(sys.stdin) if document]
app_version = str(yaml.safe_load(Path(__file__).with_name("Chart.yaml").read_text())["appVersion"])
daemonsets = [document for document in documents if document.get("kind") == "DaemonSet"]
if len(daemonsets) != 1:
    raise SystemExit(f"expected one Tetragon DaemonSet, got {len(daemonsets)}")
images = {
    container["name"]: container["image"]
    for container in daemonsets[0]["spec"]["template"]["spec"]["containers"]
}
for container, repository in (
    ("export-stdout", "argonix-api-sensor"),
    ("tetragon", "argonix-api-tetragon"),
):
    expected_image = f"ghcr.io/argonix-io/{repository}:{app_version}"
    if images.get(container) != expected_image:
        raise SystemExit(
            f"{container} must render {expected_image}, got {images.get(container)}"
        )
policy_documents = [
    document for document in documents if document.get("kind") == "TracingPolicy"
]
policies = {
    document.get("metadata", {}).get("name"): document
    for document in policy_documents
}
expected = {
    "default": {"argonix-network-connect", "argonix-runtime-security"},
    "network-only": {"argonix-network-connect"},
    "disabled": set(),
}[args.mode]
config_maps = [document for document in documents if document.get("kind") == "ConfigMap"]
sensor_config = next(
    (document for document in config_maps
     if document.get("metadata", {}).get("labels", {}).get("app.kubernetes.io/name")
     == "argonix-sensor"),
    None,
)
expected_security = "true" if args.mode == "default" else "false"
if (
    sensor_config is None
    or sensor_config.get("data", {}).get("ARGONIX_SECURITY_POLICY_EXPECTED")
    != expected_security
):
    raise SystemExit("collector security coverage setting differs from rendered policy")


def storage_bytes(quantity):
    text = str(quantity)
    for suffix, multiplier in (
        ("Ki", 1024), ("Mi", 1024 ** 2), ("Gi", 1024 ** 3), ("Ti", 1024 ** 4),
        ("K", 1000), ("M", 1000 ** 2), ("G", 1000 ** 3), ("T", 1000 ** 4),
    ):
        if text.endswith(suffix):
            return int(Decimal(text[:-len(suffix)]) * multiplier)
    return int(Decimal(text))


pod_spec = daemonsets[0]["spec"]["template"]["spec"]
state_volume = next((volume for volume in pod_spec.get("volumes", [])
                     if volume["name"] == "argonix-sensor-state"), {})
collector = next(container for container in pod_spec["containers"] if container["name"] == "export-stdout")
try:
    warning = int(sensor_config["data"]["ARGONIX_SPOOL_DISK_WARNING_BYTES"])
    capacity = storage_bytes(state_volume["emptyDir"]["sizeLimit"])
    container_limit = storage_bytes(collector["resources"]["limits"]["ephemeral-storage"])
except (KeyError, ValueError, ArithmeticError) as exc:
    raise SystemExit("collector storage must render a volume limit, an ephemeral-storage limit and an integer disk warning threshold") from exc
if not 0 < warning < capacity:
    raise SystemExit("collector disk warning must be below the state volume limit")
if container_limit < capacity:
    raise SystemExit("collector ephemeral-storage limit must cover the state volume")
try:
    catchup_pause = Decimal(sensor_config["data"]["ARGONIX_BACKLOG_DRAIN_SECONDS"])
    candidate_limit = int(sensor_config["data"]["ARGONIX_MAX_CANDIDATES_PER_WINDOW"])
    counter_limit = int(sensor_config["data"]["ARGONIX_MAX_SOURCE_METRICS_PER_WINDOW"])
except (KeyError, ValueError, ArithmeticError) as exc:
    raise SystemExit("collector catch-up pause and aggregation budgets must render as numbers") from exc
if not catchup_pause.is_finite() or not Decimal("0.5") <= catchup_pause <= 10:
    raise SystemExit("collector catch-up pause must be between 0.5 and 10 seconds")
if not 1 <= candidate_limit <= 10000 or not 100 <= counter_limit <= 100000:
    raise SystemExit("collector aggregation budgets are outside their bounded range")
# Read the same limits Helm uses instead of duplicating ranges that can drift
# when the collector's summary cadences change.
sensor_schema = json.loads(Path(__file__).with_name("values.schema.json").read_text())["properties"]["sensor"]["properties"]
for environment_key, value_key in {
    "ARGONIX_AGGREGATION_WINDOW_SECONDS": "aggregationWindowSeconds",
    "ARGONIX_NETWORK_EVIDENCE_WINDOW_SECONDS": "networkEvidenceWindowSeconds",
    "ARGONIX_PROCESS_EVIDENCE_WINDOW_SECONDS": "processEvidenceWindowSeconds",
    "ARGONIX_SECURITY_REPEAT_WINDOW_SECONDS": "securityRepeatWindowSeconds",
    "ARGONIX_DNS_EVIDENCE_WINDOW_SECONDS": "dnsEvidenceWindowSeconds",
    "ARGONIX_DNS_REPEAT_WINDOW_SECONDS": "dnsRepeatWindowSeconds",
    "ARGONIX_INTERNAL_DNS_EVIDENCE_WINDOW_SECONDS": "internalDnsEvidenceWindowSeconds",
    "ARGONIX_TRAFFIC_WINDOW_SECONDS": "trafficWindowSeconds",
    "ARGONIX_TRAFFIC_DESTINATION_WINDOW_SECONDS": "trafficDestinationWindowSeconds",
}.items():
    limits = sensor_schema[value_key]
    try:
        window = int(sensor_config["data"][environment_key])
    except (KeyError, ValueError) as exc:
        raise SystemExit(f"collector {value_key} must render as integer seconds") from exc
    if not limits["minimum"] <= window <= limits["maximum"]:
        raise SystemExit(
            f"collector {value_key} must be between {limits['minimum']} and {limits['maximum']} seconds"
        )
if set(policies) != expected or len(policy_documents) != len(policies):
    raise SystemExit(f"expected policies {sorted(expected)}, got {sorted(policies)}")
if args.check_standalone:
    standalone_dir = Path(__file__).resolve().parents[2] / "sensor" / "policies"
    for filename in ("argonix-runtime.yaml", "argonix-runtime-security.yaml"):
        standalone = yaml.safe_load((standalone_dir / filename).read_text())
        name = standalone["metadata"]["name"]
        if standalone != policies.get(name):
            raise SystemExit(f"standalone policy {filename} differs from chart policy {name}")
if args.mode == "disabled":
    raise SystemExit(0)

policy = policies["argonix-network-connect"]
network_probes = policy["spec"]["kprobes"]
network_calls = [probe.get("call") for probe in network_probes]
if network_calls != [
    "tcp_connect", "tcp_sendmsg", "tcp_sendmsg", "tcp_recvmsg", "tcp_close",
    "udp_sendmsg", "udp_sendmsg", "sys_sendto", "sys_recvfrom",
    "inet_csk_accept",
]:
    raise SystemExit(f"network policy has missing or unexpected hooks: {network_calls}")
if {option.get("name"): option.get("value") for option in policy["spec"].get("options", [])}.get(
    "disable-kprobe-multi"
) != "1":
    raise SystemExit("network policy must disable kprobe-multi for repeated sendmsg symbols")

if args.mode == "default":
    security_policy = policies["argonix-runtime-security"]
    security_probes = security_policy["spec"]["kprobes"]
    if [probe.get("call") for probe in security_probes] != [
        "security_file_open", "security_task_fix_setuid"
    ]:
        raise SystemExit("runtime security policy must contain both security hooks only")
    setuid_probe = security_probes[1]
    if setuid_probe.get("args") != [
        {"index": 0, "type": "cred"},
        {"index": 1, "type": "cred"},
        {"index": 2, "type": "int"},
    ]:
        raise SystemExit("security_task_fix_setuid must retain its typed credentials")
    file_probe = next(
        probe
        for probe in security_probes
        if probe.get("call") == "security_file_open"
    )
    selectors = file_probe["selectors"]
    if len(selectors) != 2:
        raise SystemExit("security_file_open requires guarded and kubelet selectors")
    match_args = selectors[0]["matchArgs"]
    if len(match_args) != 1 or not isinstance(match_args[0], dict):
        raise SystemExit("security_file_open must contain one typed matchArgs object")
    values = match_args[0].get("values")
    if values != [
        "/etc/shadow", "/root/.ssh", "/root/.kube", "/root/.aws",
        "/etc/kubernetes", "/run/secrets",
        "/var/run/secrets/kubernetes.io/serviceaccount", "/var/run/docker.sock",
        "/run/containerd/containerd.sock", "/var/run/crio/crio.sock",
    ]:
        raise SystemExit("security_file_open prefixes must retain all guarded paths")
    if selectors[1].get("matchArgs") != [{
        "index": 0, "operator": "Prefix", "values": ["/var/lib/kubelet"],
    }]:
        raise SystemExit("kubelet file selector must retain the guarded path")
    expected_binaries = None if args.allow_kubelet_self_access else [{
        "operator": "NotIn", "values": [
            "/home/kubernetes/bin/kubelet", "/usr/bin/kubelet",
            "/usr/local/bin/kubelet",
        ],
    }]
    if selectors[1].get("matchBinaries") != expected_binaries:
        raise SystemExit("kubelet self-access filter differs from selected mode")



dns_probe = next(
    probe
    for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "sys_sendto" and probe.get("syscall") is True
)
dns_args = {argument["index"]: argument for argument in dns_probe["args"]}
if dns_args.get(1) != {"index": 1, "type": "char_buf", "sizeArgIndex": 3}:
    raise SystemExit("sys_sendto must copy only the 1-based size-bounded user buffer")
if dns_args.get(4) != {"index": 4, "type": "sockaddr"}:
    raise SystemExit("sys_sendto must expose the destination sockaddr")
dns_match = dns_probe["selectors"][0]["matchArgs"][0]
if (
    dns_match.get("index") != 4
    or dns_match.get("operator") != "SPort"
    or dns_match.get("values") != ["53"]
):
    raise SystemExit("sys_sendto capture must be filtered to destination port 53")


recv_probe = next(
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "sys_recvfrom" and probe.get("return") is True
)
if recv_probe.get("returnArg") != {"index": 0, "type": "long"}:
    raise SystemExit("sys_recvfrom must declare its long syscall return value")
recv_args = {argument["index"]: argument for argument in recv_probe["args"]}
if recv_args.get(1) != {
    "index": 1, "type": "char_buf", "returnCopy": True, "sizeArgIndex": 3
}:
    raise SystemExit("sys_recvfrom DNS response buffer must be return-copied and bounded")

tcp_dns_send = next(
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "tcp_sendmsg"
    and any(argument.get("type") == "iov_iter" for argument in probe.get("args", []))
)
tcp_iter = next(
    argument for argument in tcp_dns_send["args"]
    if argument.get("type") == "iov_iter"
)
if tcp_iter.get("resolve") != "msg_iter" or tcp_iter.get("maxData") is not False:
    raise SystemExit("TCP DNS payload hook must resolve a capped msg_iter")
tcp_match = tcp_dns_send["selectors"][0]["matchArgs"][0]
if tcp_match.get("operator") != "DPort" or tcp_match.get("values") != ["53"]:
    raise SystemExit("TCP DNS payload hook must be filtered to destination port 53")

tcp_dns_recv = next(
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "tcp_recvmsg"
)
if tcp_dns_recv.get("returnArg") != {"index": 0, "type": "int"}:
    raise SystemExit("tcp_recvmsg must declare its int return value")

udp_dns_probes = [
    probe for probe in policy["spec"]["kprobes"]
    if probe.get("call") == "udp_sendmsg"
    and any(argument.get("type") == "iov_iter" for argument in probe.get("args", []))
]
if len(udp_dns_probes) != 1:
    raise SystemExit("one bounded UDP DNS payload hook is required")
for probe in udp_dns_probes:
    iterator = next(
        argument for argument in probe["args"]
        if argument.get("type") == "iov_iter"
    )
    if iterator.get("resolve") != "msg_iter" or iterator.get("maxData") is not False:
        raise SystemExit(f"{probe['call']} must resolve a capped msg_iter")
    match = probe["selectors"][0]["matchArgs"][0]
    if match.get("operator") != "DPort" or match.get("values") != ["53"]:
        raise SystemExit(f"{probe['call']} must be filtered to destination port 53")
