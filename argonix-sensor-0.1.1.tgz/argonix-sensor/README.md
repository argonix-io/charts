# Argonix Sensor Helm Chart

Provider-neutral runtime network sensor for Linux Kubernetes nodes. The chart
wraps the upstream Apache-2.0 Tetragon chart and replaces its JSON export
sidecar with the Python Argonix collector.

Supported Kubernetes environments include GKE, EKS, AKS, OVH Managed
Kubernetes, and on-premises clusters. The collector contains no cloud-provider
branching; `sensor.clusterName` is the stable identity chosen by the operator.

## Prerequisites

- Linux worker nodes with a Tetragon-supported kernel.
- Outbound HTTPS access from nodes to the Argonix API.
- An Argonix organization API key with `runtime-sensors:write` permission.
- Helm 3 or 4 and permission to install cluster-scoped Tetragon CRDs/RBAC.

Windows nodes are not selected by the upstream Tetragon DaemonSet and require
the future WFP/ETW sensor.

## Install

Create the credential without putting it in Helm values or shell history:

```bash
kubectl create namespace argonix-system
kubectl -n argonix-system create secret generic argonix-sensor-credentials \
  --from-literal=ARGONIX_API_KEY="$ARGONIX_API_KEY"
```

Install from the Argonix repository:

```bash
helm repo add argonix https://charts.argonix.io
helm repo update argonix
helm upgrade --install argonix-sensor argonix/argonix-sensor \
  --namespace argonix-system \
  --set sensor.apiBaseUrl=https://api.example.com/api/0.1 \
  --set sensor.clusterName=production-eu
```

The upstream Tetragon DaemonSet runs one pod per Linux node. Each pod contains:

1. the privileged upstream Tetragon container;
2. the non-root Argonix collector sidecar;
3. a node-local 256 MiB spool volume shared only inside the pod.

The node name comes from the Kubernetes Downward API. Each node enrolls
idempotently as `kubernetes/<clusterName>/<nodeName>`.

Spool payloads are encrypted with Fernet before SQLite persistence. Add an
independent `ARGONIX_SPOOL_KEY` entry to `argonix-sensor-credentials` when
possible. Without it, version 0.1.1 derives the encryption key from the scoped
API key; drain the spool before rotating that API key.

## Existing Tetragon installation

Do not install two Tetragon DaemonSets on the same nodes. The initial supported
path is to replace the existing release with this wrapper chart while preserving
the upstream Tetragon values. Sidecar-only attachment to an independently
managed Tetragon release is a later packaging mode.

## Verify

```bash
kubectl -n argonix-system get daemonset,pods -l app.kubernetes.io/part-of=tetragon
kubectl -n argonix-system logs -l app.kubernetes.io/name=tetragon \
  -c export-stdout --tail=50
```

## Optional mTLS

The collector always requires its scoped Argonix API key. To additionally
authenticate the node at the TLS layer, create the optional fixed-name Secret:

```bash
kubectl -n argonix-system create secret tls argonix-sensor-mtls \
  --cert=node-client.crt \
  --key=node-client.key
```

The API ingress or service mesh must validate the client certificate against
the organization CA before forwarding the request to Django. If the Secret is
absent, the collector uses ordinary server-authenticated HTTPS. Automatic
certificate issuance and rotation are not part of version 0.1.1.

## Linux VM mode

VMs use the same Python package and API contract but not this Helm chart:

1. install upstream Tetragon as a package/container or `systemd` service;
2. export JSON events to `/var/log/tetragon/tetragon.log`;
3. run `argonix-sensor` as a separate `systemd` service with platform
  `vm_linux`, `ARGONIX_NODE_NAME` set to a stable cloud instance/host identity,
  and the same scoped API key.

Build or download the wheel, then install the hardened service:

```bash
sudo sensor/systemd/install.sh dist/argonix_sensor-0.1.1-py3-none-any.whl
sudo editor /etc/argonix-sensor/sensor.env
sudo systemctl start argonix-sensor
sudo systemctl status argonix-sensor
```

The collector runs unprivileged. Only upstream Tetragon needs kernel/eBPF
privileges. The service can read `/var/log/tetragon` and write only its private
state directory.