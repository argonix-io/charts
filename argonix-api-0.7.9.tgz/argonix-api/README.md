# Argonix API Helm chart

The current release pair is chart `0.7.9` with application images `0.7.9`.
Use `--version 0.7.9` for Helm and pin API, frontend, scanner and inference
images to `0.7.9` when overriding image tags. The English and French
self-hosted installation guides contain matching install and upgrade examples.

Historical resource identity resolution uses concurrent indexes. When upgrading,
run the chart's migration job before serving the new API.

The frontend rolls out on each `helm upgrade`, including when its image tag
stays the same. With the shared default pull policy, `latest` is resolved
against the registry when the container starts. Set `frontend.image.pullPolicy`
to override the policy for the frontend.

## Release notes and update checks

Review the [release notes](https://argonix.io/en/docs#releases/overview) and
[API upgrade guide](https://argonix.io/en/docs#releases/upgrade-api) for your target
version. The **Help** menu compares installed versions with the public release
catalog. For offline deployments, set `config.releaseChecksEnabled: false`.

# Cloud workload identity

Cloud connectors support the pod identity when their stored credentials are empty.
Configure the source identity through the existing `serviceAccount.create`, `name`
and `annotations` values. To reuse `argonix/default`, set `create: false` and
`name: default`; annotations on existing accounts stay externally managed.

- GCP: GKE Workload Identity / ADC; set each connector's `project_id` and optionally
  `impersonate_service_account` for a different target account.
- AWS: IRSA or EKS Pod Identity; optionally set `role_arn` and `external_id` per
  connector to assume another authorized role.
- Azure: AKS Workload Identity or managed identity; leave `client_secret` empty.
  For AKS, set the service account client/tenant annotations and the backend label:

```yaml
podLabels:
  azure.workload.identity/use: "true"
```

The label reaches the API, API WebSocket, runtime ingestion, all workers, Beat and
migration hook; frontend, landing, local inference and embedding backfill are
excluded. Chart selector labels cannot be overridden by `podLabels`.

Cloud IAM grants and federation trust must already exist. The shared backend
identity has the combined permissions of all authorized targets; separate
connectors do not create pod isolation. Apply matching application and chart
builds containing this change, then restart the affected pods.

See the [English setup guide](../../docs/guides/cloud-workload-identity.md),
[guide français](../../docs/guides/fr/cloud-workload-identity.md) and ready-to-overlay
values for [GKE](../../docs/examples/gcp-workload-identity-values.yaml),
[EKS](../../docs/examples/aws-workload-identity-values.yaml) and
[AKS](../../docs/examples/azure-workload-identity-values.yaml).

# Worker queues

Health-report execution limits are shared across the notebook's connectors and
resumes. The defaults give a complete application or estate report a high
allowance of 1,000 model calls, 10,000 tool calls, 20,000,000 accumulated model
tokens and 10,000 stages per execution, independently of billing quotas:

```yaml
healthChecks:
  executionLimits:
    modelCalls: 1000
    toolCalls: 10000
    tokens: 20000000
    stages: 10000
  model:
    maxOutputTokens: 65536
    timeoutSeconds: 600
    providerRetries: 8
  probes:
    sourceTimeoutSeconds: 600
    totalTimeoutSeconds: 7200
  logEvidence:
    maxPageBytes: 67108864       # 64 MiB
    maxSourceBytes: 536870912   # 512 MiB
```

These positive-integer values populate `ARGOS_HEALTH_MAX_MODEL_CALLS`,
`ARGOS_HEALTH_MAX_TOOL_CALLS`, `ARGOS_HEALTH_MAX_TOKENS` and
`ARGOS_HEALTH_MAX_STAGES` in the shared ConfigMap. Apply the updated chart with
the matching application image; the ConfigMap checksum rolls the API and workers,
including `health-worker`. For external workers, set the same environment
variables and restart their processes. A stopped execution keeps its saved
observations without an overall health score; generate a new report after
changing its limits.

The `model`, `probes` and `logEvidence` groups configure the corresponding
`ARGOS_HEALTH_LLM_*`, `ARGOS_HEALTH_PROVIDER_RETRIES`,
`ARGOS_HEALTH_PROBE_*` and `ARGOS_HEALTH_LOG_MAX_*` environment variables.
Model retries handle temporary 429/timeouts with backoff and provider
`Retry-After`, using the same saved evidence. A successful response resets the
consecutive retry count. Incomplete JSON is recovered before it is accepted as
a completed connector report. These Health settings do not change Patrol's
short probe limits. A bounded log sample is shown as a scope limitation;
failed reads and missing evidence remain explicit and prevent a health verdict.
Sampled logs cannot prove that earlier findings were fixed or authorize
automatic corrections. Apply the application and chart together, then generate
a new report; earlier stored reports retain their original evidence.

`detectionWorker.enabled` defaults to `true`. Its single worker consumes
`detection`, keeping `security.evaluate_detection_rules` out of the general queue
where long inventory jobs can delay or expire evaluations. It uses the shared
worker image, with one process and a 300-second shutdown grace period. If disabled,
the general worker consumes `detection`; disabling both workers requires an
external Celery worker subscribed to that queue.

Deploy the application image, Beat and worker images together with this chart
change, so producers and the detection consumer agree on routing. Explicit queue
overrides on custom DatabaseScheduler entries must also target `detection`.
Existing messages already published to `celery` drain on the general workers;
do not purge them. Queue isolation prevents inventory starvation but does not
replay events that have already left a detection rule's evaluation window.

`applicationPrioritiesWorker.enabled` defaults to `true`. Its dedicated worker
consumes only `application-priorities`, keeping interactive application assessment
out of the general inventory and AI backlog. It uses the shared worker image,
one process, 1 GiB requested memory (2 GiB limit) and a 360-second shutdown grace
period covering the task's 330-second hard limit. Optional `livenessProbe` and
`readinessProbe` values use the same format as the general worker. Disabling it
explicitly makes the general worker consume the queue; when both are disabled,
provide an external consumer subscribed to `application-priorities`.

Deploy the updated API and worker image with this chart so producers and consumers
agree on routing. Previously published priority jobs remain on `celery` and drain
there; do not purge queues during rollout. See
[the application priority queue runbook](../../docs-internal/operations/2026-11-03-application-priority-queue.md)
for checks of pending assessments.

`runtimeSummaryWorker.enabled` defaults to `true`. Its single worker consumes
`runtime-summary`, keeping hourly network dashboard preparation out of the general
queue. It uses the worker image. If disabled, the general worker consumes this
queue too; external Celery deployments must add a consumer explicitly. Apply
inventory migrations `0074`–`0076` before starting the updated API and workers. Existing
hourly summaries are rebuilt progressively; reads use exact raw data until ready.

`runtimeMaintenanceWorker.enabled` defaults to `true`. Its single worker
consumes `runtime-maintenance` for traffic compaction and raw observation
retention. This prevents short-lived compaction jobs from expiring behind
unrelated long tasks. If disabled, the general worker consumes the queue.

Enable `finopsWorker.enabled` to deploy a dedicated worker consuming `finops`.
With this option enabled, the general worker consumes only `celery`. When it is
disabled (the default), the general worker consumes both queues for compatibility.
Deploy the application, scanner and inference images with chart 0.2.0 together.

FinOps collection, allocation, optimization, anomaly detection and budget tasks
route to `finops`. Agent investigations and approved remediation retain the
general worker's larger memory budget. Monitor tasks and monitor alert evaluation
and delivery route to `monitors`; external alert ingestion and AI investigations
remain on their existing queues.

Routing applies to newly published messages. Existing messages in `celery` drain
there; do not purge them during rollout. Explicit queue overrides on custom
DatabaseScheduler entries take precedence over application routes.

Observed network-edge preparation also routes to `runtime-summary`. It dispatches
one complete hour per organization, newest hour first, with a 120-second soft
limit and 150-second hard limit. Disjoint hours can run concurrently; overlapping
buckets share a writer lock. SQL timeouts are local to each transaction, without
changing the shared database server. Retention probes preserve oldest-first
ordering, allowing the existing organization/time index to serve continuation
checks. Default DNS retention is 24 hours (`dns_days=1`); raw flow/process and
sensor cursor retention remains 3 days, hourly edges 90 days.
Operational-signal retention separates active and resolved signals so the
existing organization/status/time index serves both the delete page and its
continuation check; the status is preserved with the cursor across retries.

Inventory snapshots project current relationships in two narrow SQL joins,
excluding expired relationships and disappeared peers from the new state.
Earlier snapshots retain their original topology. Snapshot publication is
serialized per resource and cannot move backward behind a concurrent refresh.
Unchanged observation/profile JSON is not rewritten, and network identities
are refreshed in one batched upsert while preserving their first-seen history.
Expired recalculation deliveries release only their own pending token when
Celery discards them, including inventory syncs. A delivery that expired in a
busy queue no longer blocks the next refresh for the execution-lease duration.
Kubernetes syncs reconcile Argo CD ownership only for their own cluster;
Argo CD syncs retain organization-wide reconciliation. Ownership refresh and
removal use ordered batches of at most 500 edge IDs, preserving other clusters.

The shared inference process caches up to 512 item results for five minutes
(hash keys, memory only), coalesces identical work and preserves input order.
Queued calls can wait up to 90 seconds rather than failing after 30 seconds.
Busy responses include `Retry-After`; application clients retry only HTTP 503,
at most eight attempts with exponential backoff within one 120-second budget.
Empty knowledge scopes skip inference entirely. Standard three-document RAG
responses rerank at most eight fused candidates; explicitly larger result sets
remain supported. Reranking uses at most 768 tokens per pair and reserves space
for the document by bounding the query to 128 tokens. Deploy both the application
and inference images. Automatic security investigations keep hybrid dense/BM25
runbook retrieval and skip the optional cross-encoder, reserving it for explicit
expert retrieval rather than competing with interactive calls during alert bursts.

The next application build stages hourly edge aggregates with PostgreSQL COPY
and reconciles them in set-based SQL. Bucket locks, atomic publication, stable
IDs and unchanged modification times are preserved; no shared SQL settings or
schema migration are required. This avoids hundreds of ORM write batches timing
out and rolling back the same complete hour repeatedly.
Staged writes are limited to 5,000 edges per SQL statement so large buckets
retain the existing 10-second statement budget and 120-second task budget.

SRE patrols enqueue due log mining on its existing coalesced background task,
then consume persisted evidence. Pending refreshes are explicitly incomplete
coverage and cannot prove recovery. Report rendering uses a 60-second LLM
timeout with no SDK retries; worker cancellation propagates through the report
fallback. Deploy the updated image to runtime-summary and health workers.
Monitor collection clears check timestamp ordering before selecting distinct
monitor IDs, so each history is read once rather than once per check result.
Finding collection reads only report fields, reuses inventory attribution per
connector/resource, and saves patrol state in bounded bulk upserts that preserve
operator feedback and investigation/MR markers.
Threat/log/application-health collection projects report fields and resource
IDs without loading unused scan summaries, raw patterns or resource payloads.
Collection propagates worker cancellation instead of falling through to a hard kill.
Stale-edge cleanup compares only bucket identities and deletes bounded primary-key
batches, avoiding expensive anti-join plans on freshly ingested hours.
Patrols have an explicit budget of 2,000 records per source. Exceeding it marks
coverage incomplete and prevents unseen signals from being resolved. The LLM
prompt includes at most 200 prioritized signals plus observed/omitted totals;
persisted patrol state retains all observations from the bounded collection.
Patrols also reuse the existing coalesced operational-evidence refresh job rather
than materializing it inline. Only a successful refresh records 15-minute freshness;
pending or stale evidence is explicit incomplete coverage, never proof of recovery.
Roll the general workers as well so their successful refreshes publish freshness.
The additive correlation pass uses the same 2,000-row work budget as its other
source materializers rather than loading every active signal into memory.
Raw patrol probes have a 20-second per-connector and 120-second aggregate read
budget; recent-change collection has 60 seconds. Read cancellation escapes broad
SDK retry handlers, restores the signal handler, and records unavailable coverage.
The progress marker names a connector before contacting it.
Optional patrol application/source graph enrichment is limited to five roots and
30 seconds. Its truncation/unavailability is explicit and cannot prove recovery;
the sweep never retries the same enrichment after collecting it once.

The monitors worker defaults to `dnsConfig.options: [{name: ndots, value: "1"}]`,
reducing Kubernetes search expansions for dotted external targets while retaining
the search list for short service names. This is scoped to monitors pods. Set
`monitorsWorker.dnsConfig: null` to inherit the cluster DNS defaults. Kubernetes
documents pod DNS options [here](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-config).

The next API build reuses the TLS certificate of each fresh HTTP probe instead
of making a second DNS/TCP/TLS connection just to read its expiry. When transport
metadata is unavailable or the redirect changes origin, the separate certificate
probe remains the fallback. Immutable DNS/process ingestion uses PostgreSQL
`ON CONFLICT DO NOTHING RETURNING` to avoid pre-reading these large tables; batch
transactions and uniqueness constraints still preserve replay/rollback behavior.
These changes require the new API/worker image and no shared SQL configuration.

Datadog log search reports missing or inaccessible indexes explicitly as
`logs_indexes_unavailable`, rather than a successful empty result. These HTTP
400 failures are cached for five minutes per worker and credential/index selection
to avoid repeating an impossible query. Changing keys or the optional connector
`log_indexes` selection bypasses that cache; provider-side fixes are retried after
expiry. Configure accessible Logs indexes and application-key permissions in
Datadog. The connector cannot create missing indexes or grant itself access.

The dedicated FinOps worker defaults to one process, a 1Gi memory request and a
4Gi limit. Its 660-second shutdown grace accommodates the ten-minute cost-sync
and vSphere task limits. Other FinOps tasks can have different execution limits.
Size requests and limits against peak measurements after rollout.

# Dedicated AI Code Hunter worker

The AI tab is available on Code projects without selecting a scanner engine.
Chart 0.2.5 deploys `hunterWorker` by default so its queue has a consumer.
`security.run_code_analysis` stays on `scanner`;
`security.run_code_hunter` consumes only `code-hunter`. Resume and
recovery also dispatch AI batches to that dedicated queue. Schedule dispatch and
recovery coordination remain on the general queue. There is no AI fallback to a
scanner or general worker, so without a Hunter consumer AI batches remain queued.

Image precedence is `hunterWorker.image` when its repository is configured,
then a configured `scannerWorker.image`, then the standard API `image`. Both
`Dockerfile.django` and `Dockerfile.scanner` ship Git, the organization LLM SDKs
and `argonix.scanner_celery` under `/app`. Deploy the selected image from the same
revision as the application. A custom image must preserve that working directory,
readable application files and these runtime dependencies. The startup probe
checks them and the writable temporary volumes. The worker loads no local model
weights and requires no GPU. `hunterWorker.enabled=false` is still supported,
but an external `code-hunter` consumer is then needed for AI reviews to progress.

Defaults are one replica, concurrency one, prefetch one, a 250m CPU/1Gi memory
request and a one CPU/2Gi memory limit. This reservation is added by the default
deployment even before a user starts an AI review. Writable checkout storage is an ephemeral
5Gi volume; `/tmp` is an additional 1Gi volume. The filesystem otherwise stays
read-only and the worker runs as UID/GID 10001 without Linux capabilities or an
automounted Kubernetes service account token. Override resources based on
repository size and measured peak use. Increasing replicas or concurrency also
increases simultaneous hosted LLM requests and potential cost.

The 1020-second shutdown grace accommodates the Hunter task's 900-second soft
and 960-second hard limits, including checkout. Celery receives SIGTERM directly
and can finish the active batch. A killed batch can be redelivered against the
same checkpoint; already completed batches are preserved. Deployment does not
clear messages from any queue.

`hunterWorker.networkPolicy.enabled` is optional and disabled by default. When
enabled, the policy denies ingress and allows DNS plus public HTTPS for Git and
hosted LLM endpoints. Unlike the scanner policy, it does not implicitly allow
all private networks. Set `privateEgressCidrs` to the required private DB, broker,
Git or LLM destinations; `privateEgressPorts` defaults to TCP 443, 5432 and 6379.
Use `extraEgress` for namespace/pod selectors, TLS broker ports or other private
LLM/artifact storage endpoints. CNI handling of service address translation must
be considered when choosing CIDRs; a namespace/pod selector is often appropriate
for in-cluster DB and broker pods. Other applicable policies can add permissions.

The optional `hunterWorker.existingSecret` allows a restricted environment. It
must retain the database and broker connection settings, shared `SECRET_KEY`
and any required artifact-storage credentials. Organization LLM credentials are
read through the existing organization settings, not copied into chart values.

Validate the chart locally without accessing a cluster:

```sh
helm dependency build charts/api
python -m unittest discover -s charts/api/tests -q
helm lint charts/api
```

# Dedicated inference (breaking change in 0.2.0)

All embedding and reranking calls use the internal `-inference:8001` service.
There is no local backend or local fallback. The API and workers no longer ship
model weights, PyTorch, Transformers or ONNX Runtime. The dedicated image loads
Qwen3-Embedding-0.6B and Qwen3-Reranker-0.6B once, using native Transformers
on CPU. The embedding output remains 1024-dimensional and normalized. Retrieval
queries receive a task instruction; documents and finding comparisons use
unprompted encoding. Embeddings use last-token pooling. Reranking scores the
model's yes/no logits and is enabled in the RAG pipeline.

The Qwen switch clears all four sets of persisted embeddings in migration 0138.
Stop old writers for this direct cutover. The chart's `embeddingBackfill` Job
rebuilds chunks, findings, tickets and ignores, resuming committed batches after
failure. Wait for its completion before resuming workloads. See
[the deployment and rebuild procedure](../../docs/features/qwen3-embeddings.md).

The service always has one replica/process. Inference runs serially in batches
of eight, with at most eight pending/active requests; saturation returns HTTP
503. Clients have bounded timeouts and do not retry automatically. During a
service restart, RAG requests can fail until the models are ready. The existing
retrieval behaviour on reranking failure (returning unreranked passages) remains.

Helm sets `ARGOS_INFERENCE_URL` for the API and workers. The service is ClusterIP
only, with ingress restricted to this release's pods in the same namespace.
Calls use an HMAC-derived bearer token based on the shared Django `SECRET_KEY`;
only that secret entry is passed to the inference pod, not database credentials.
Model weights are downloaded at image build and runtime is offline.

For development, build `Dockerfile.inference`, expose port 8001, and supply the
same `SECRET_KEY` as Django. The application's default inference URL is
`http://127.0.0.1:8001`. No Django database or Celery worker is needed in that
container. Keep request logging free of input text and vectors.

The inference pod reserves 6Gi and has a 12Gi limit. Other components still need
memory for scans, inventory, document parsing and cost calculations; moving
models out does not remove those workloads. Lowering memory requests changes
reservations, not actual usage.

# FinOps collection

Cost anomalies aggregate daily totals in one streaming query per organization;
only detected spikes require attribution/upsert queries. Missing baseline days
are not filled with zeros.

vSphere performance collection uses the existing connector, with at most 20 VMs
per SOAP request, a 60-second connection timeout, and progress saved per batch.
Inventory pagination reuses a connector-local snapshot for up to five minutes;
requesting page one refreshes it. Missing metrics, failed batches or truncated
inventory prevent automatic resolution of previous recommendations. A soft task
timeout marks the run failed; the hard limit is a final process safeguard.

## Runtime stability and storage in 0.7.2

Connector collection uses a dedicated `inventory` queue (`inventoryWorker`, one
replica and two slots by default). Continuations take priority over new roots;
only one complete Kubernetes collection can be active per connector. If the
dedicated worker is disabled, the general worker consumes its queue. Graceful
termination exceeds the longest inventory stage budget.

With the dispatcher setting introduced after API 0.7.2, add an entry with
`name: INVENTORY_KUBERNETES_SYNC_INTERVAL_SECONDS` and `value: "1800"` to
the `beat.env` list to dispatch Kubernetes inventory every
30 minutes on a shared database. The default is 600
seconds, with values below 300 raised to 300. Supported intervals are 5, 6, 10,
12, 15, 20, 30 or 60 whole minutes (maximum 3600 seconds); other values fail
configuration validation. Dispatches stay aligned to wall-clock minutes, so
1800 seconds matches the all-inventory dispatcher. The persisted Beat entry keeps its original name,
so an upgrade updates it rather than creating a second dispatcher. The
all-inventory dispatcher stays at 30 minutes and active collections remain
deduplicated; network-edge materialization stays at five minutes.

Observed network summaries publish only changed rows in bounded batches. FK
contention fails before the expensive calculation and is retried with bounded
backoff. Exhausted retries remain failures. Attack-path calculations retain
per-tenant serialization without blocking ingestion's foreign-key checks.

Snapshot fingerprints ignore heartbeat-only Argo CD timestamps and equivalent
source ordering. Ordinary label heartbeats update narrow timestamp columns;
current timestamp labels reuse their row. Existing historical snapshots and
label assertions are retained.

Successful monitor response snippets default to 512 bytes
(`config.monitorSuccessBodyMaxBytes` / `MONITOR_SUCCESS_BODY_MAX_BYTES`).
Assertions still inspect the complete response. Failed/degraded response details
remain available. Scanner and code-hunter work volumes default to 25Gi per pod
instead of 100Gi; browser sessions use 10Gi. Size repository work claims for
concurrent checkout/report budgets (for example, 50Gi for two 20Gi checkout slots). Existing PVCs cannot shrink: complete active jobs and
replace their pods to allocate new, smaller temporary claims.

## Country geolocation for network detection

Country policies (`network_match` with `in_countries` / `outside_countries`) use a
local country MMDB for IPv4 and IPv6. IPLocate and MaxMind Country databases are
supported. The API needs the database for read-only previews; the dedicated
detection worker and the general worker need it for evaluation, including when
the detection queue falls back to the general worker. GeoIP is disabled by
default and database files are not bundled in application images.

### IPLocate: automatic updates without an account

Enable public IPLocate country data with no account, API key or Secret:

```yaml
geoip:
  enabled: true
  provider: iplocate
  updater:
    frequencyHours: 24
```

Fresh configurations also select IPLocate when `provider` is left empty.
For compatibility, empty `provider` selects MaxMind when `existingClaim` or
`updater.existingSecret` is configured. Set the provider explicitly when adding
an IPLocate PVC or switching an existing MaxMind installation.

Each API, general-worker and detection-worker pod gets a private `emptyDir`.
An init container downloads and validates the first database before the
application starts; a failed first download keeps that pod initializing.
A sidecar checks for updates every 24 hours by default using the same configured
API image and this standalone command:

```sh
python -m argonix.security.geoip_update \
  --destination /var/lib/argonix/geoip/ip-to-country.mmdb \
  --interval-hours 24
```

The init container omits `--interval-hours` for a single download. The updater
uses the official [IPLocate public country database](https://github.com/iplocate/ip-address-databases/tree/main/ip-to-country).
Set `geoip.updater.url` to an HTTPS MMDB mirror when needed; it is passed as
`--url` and never used for per-IP requests. The command validates country schema
and dual-stack support, replaces data atomically, and keeps the last readable
database when a refresh fails. Periodic failures are retried without interrupting
the application. Public mirrors can lag the upstream data; check database
freshness rather than assuming a successful download means current data.

IP address data powered by [IPLocate.io](https://www.iplocate.io/).
IPLocate's free data is distributed under
[CC BY-SA 4.0](https://github.com/iplocate/ip-address-databases#license-for-free-ip-address-databases);
retain the provider attribution wherever this data is used or redistributed.

### MaxMind: existing or licensed Country databases

MaxMind remains supported. Create a Kubernetes Secret through your normal
secret-management process, with `accountId` and `licenseKey` keys for a MaxMind
account licensed to download the selected edition:

```yaml
geoip:
  enabled: true
  provider: maxmind
  editionId: GeoLite2-Country  # or GeoIP2-Country with the appropriate license
  updater:
    existingSecret: maxmind-download
    frequencyHours: 24
```

This provider uses the official `ghcr.io/maxmind/geoipupdate:v8.0.0` image, with
credentials supplied only to its updater containers. A failed refresh restarts
the updater and preserves previously downloaded data. See
[MaxMind update guidance](https://dev.maxmind.com/geoip/updating-databases/) and
[official updater configuration](https://github.com/maxmind/geoipupdate/blob/v8.0.0/doc/docker.md).

### Shared runtime and offline distribution

Both providers run their updater containers as non-root with a read-only root
filesystem; the database and temporary directories remain writable. The pod
gets `fsGroup: 65532` when no explicit fsGroup is configured. Application
containers mount the database directory read-only. IPLocate updater containers
receive no application database credentials or MaxMind secrets.

The application reopens an atomically replaced database without a restart.
Preview exposes availability, provider, database metadata, freshness and coverage.
`geoip.maxAgeDays` (30 by default) is an informational freshness threshold, so
readable older data remains usable. An unavailable or invalid database suppresses
country-dependent detections and is reported by preview; it is never treated as
an unknown country that should trigger every rule. Monitor update failures and
database freshness in your normal operations.

For offline deployments or many replicas, distribute a database centrally and
mount an existing claim instead:

```yaml
geoip:
  enabled: true
  provider: iplocate
  existingClaim: geoip-country-data
```

The claim must contain `ip-to-country.mmdb` at its root for IPLocate. For MaxMind,
set `provider: maxmind` and provide `GeoLite2-Country.mmdb` or
`GeoIP2-Country.mmdb` according to `editionId`. Files must be readable by the
application user. All consumers mount the claim read-only; no updater or
credentials are added. Use storage supporting cross-node access, normally
ReadWriteMany. An external writer must keep data current and replace the MMDB
atomically. Mount the **directory**, never a single-file `subPath`, so running
processes observe replacement files. Per-pod provisioning checks independently;
centralized distribution can reduce download volume and account limits.

The chart sets `GEOIP_COUNTRY_DATABASE` to
`/var/lib/argonix/geoip/ip-to-country.mmdb` for IPLocate or
`/var/lib/argonix/geoip/<editionId>.mmdb` for MaxMind, and sets
`GEOIP_DATABASE_MAX_AGE_DAYS` from `geoip.maxAgeDays`. Standalone or external
consumers must mount the appropriate database and configure these variables
themselves. Only data updates contact the download provider; detecting a flow
never sends its IP to an external geolocation service.
