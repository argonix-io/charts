{{/*
Expand the name of the chart.
*/}}
{{- define "argonix-worker.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "argonix-worker.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "argonix-worker.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "argonix-worker.labels" -}}
helm.sh/chart: {{ include "argonix-worker.chart" . }}
{{ include "argonix-worker.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "argonix-worker.selectorLabels" -}}
app.kubernetes.io/name: {{ include "argonix-worker.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "argonix-worker.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "argonix-worker.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Image helper
*/}}
{{- define "argonix-worker.image" -}}
{{- $registry := .Values.global.imageRegistry | default .Values.image.registry -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry .Values.image.repository $tag -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository $tag -}}
{{- end -}}
{{- end }}

{{/*
ConfigMap ref name
*/}}
{{- define "argonix-worker.configMapRef" -}}
{{- .Values.configMapRef | default (include "argonix-worker.fullname" .) -}}
{{- end }}

{{/*
Secret ref name
*/}}
{{- define "argonix-worker.secretRef" -}}
{{- .Values.secretRef | default (include "argonix-worker.secretName" .) -}}
{{- end }}

{{/*
Secret name (handles existingSecret)
*/}}
{{- define "argonix-worker.secretName" -}}
{{- if .Values.secrets.existingSecret -}}
{{- .Values.secrets.existingSecret -}}
{{- else -}}
{{- include "argonix-worker.fullname" . -}}
{{- end -}}
{{- end }}
