# Argonix Sensor Helm Chart

Provider-neutral runtime network sensor for Linux Kubernetes nodes. The chart
wraps the upstream Apache-2.0 Tetragon chart and replaces its JSON export
sidecar with the Python Argonix collector.

The Helm chart and collector use independent semantic versions. `Chart.yaml`
`version` identifies the deployment package; `appVersion` identifies the
collector and therefore matches the `argonix-api-sensor` image tag. For example,
chart `0.1.9` legitimately deploys collector/image `0.1.7`. CI rejects a sensor
image tag that differs from `appVersion`.

Supported Kubernetes environments include GKE, EKS, AKS, OVH Managed
Kubernetes, and on-premises clusters. The collector contains no cloud-provider
branching; `sensor.clusterName` is the stable identity chosen by the operator.

## Prerequisites

- Linux worker nodes with a Tetragon-supported kernel.
- Outbound HTTPS access from nodes to the Argonix API.
- An Argonix organization API key with `runtime-sensors:write` permission.
- Helm 3 or 4 and permission to install cluster-scoped Tetragon CRDs/RBAC.

Tetragon needs host networking, host paths, `/proc`, BPF maps, and a privileged
container. It cannot run in a namespace where Pod Security Admission enforces
`baseline` or `restricted`. Use a dedicated namespace such as
`argonix-sensor` with `enforce=privileged`; keep `warn` and `audit` at
`baseline` so policy drift remains visible. Do not weaken the namespace that
hosts the Argonix API.

Windows nodes are not selected by the upstream Tetragon DaemonSet and require
the future WFP/ETW sensor.

The chart enforces `kubernetes.io/os: linux` on the DaemonSet. This selector
must not be removed: Windows nodes do not expose Linux `/proc` or BPF host paths
and otherwise fail with `hostPath type check failed: /proc is not a directory`.

When upgrading across an event-contract compatibility fix, deploy the Argonix
API first and wait for existing sensors to drain their spools before upgrading
this chart. The current spool volume is an `emptyDir`: it survives collector
container restarts but not replacement of the DaemonSet pod.

If event production is faster than an older collector can drain, temporarily
set `sensor.tracingPolicy.enabled=false` on the current release. This removes
only `argonix-network-connect` without replacing the DaemonSet pods, so their
existing `emptyDir` spools remain available. Wait until every fresh sensor
reports `spool_events=0`, then upgrade the chart and re-enable the policy.

Collector 0.1.7 aggregates network and process observations locally over
60-second windows. By default each sensor retains at most 200 candidate
signatures and emits at most 20 observations per window. Repeated socket
lifecycles preserve connection counts, bytes and time bounds in one row;
first-seen signatures reserve half the output budget, and process-enforcement
or denied events take priority when the candidate set is full.
Open TCP lifecycle state and per-window socket metrics are independently capped
at 10,000 entries. Overflow remains visible in aggregate evidence instead of
growing collector memory without limit. On `SIGTERM`, the collector flushes the
partial window to its encrypted spool and gives the sender a bounded drain period
before exiting.

The hard default ceiling is therefore 1,200 rows/hour/node across network and
process data. For 27 nodes this is 32,400 rows/hour, approximately 50-80 MB/hour
at the measured PostgreSQL row and index footprint. Raw observations and boot
cursors are retained for 7 days; compact hourly edges are retained for 365
days. `aggregation_dropped_events` in sensor health reports observations omitted
by the intentional cap. `spool_dropped_events` remains a delivery failure signal
and marks the sensor `degraded`.
The API independently enforces the same 20-row sensor/window ceiling across
network and process rows, so collector restarts cannot multiply database usage;
idempotent retries remain accepted and advance their cursor.

Traffic-rate metrics use a separate loss-resistant path and are not affected by
`sensor.sampleRate` or the evidence-row ceiling. Every 60-second window emits a
workload total, an external-egress total when applicable, and at most
`sensor.maxTrafficDestinations` destination series per node. Workload cardinality
is capped by `sensor.maxTrafficScopes`; overflows are reported through sensor
health while already admitted workload totals remain intact. These metrics are
retained for 30 days by the API.

The displayed rate is calculated from the byte count requested by application
send calls (`tcp_sendmsg` and `udp_sendmsg`). It is suitable for detecting large
external transfers and relative spikes, but it is deliberately labelled
**partial**: it is not an interface counter, does not include protocol overhead,
does not prove successful delivery, and does not currently measure received
payload throughput. No payload content is collected.

The collector drains one batch every five seconds, with a stable per-sensor
offset, while the spool is non-empty and returns to `sensor.flushSeconds` when
idle. A queue of 5,000 events or any spool drop marks the sensor `degraded`; it
returns to `healthy` after recovery. `sensor.sampleRate` remains `1.0` by default:
the bounded aggregation policy replaces blind random sampling.

## Install

Create and label the dedicated namespace, then create the credential without
putting it in Helm values or shell history:

```bash
kubectl create namespace argonix-sensor
kubectl label namespace argonix-sensor \
  pod-security.kubernetes.io/enforce=privileged \
  pod-security.kubernetes.io/enforce-version=latest \
  pod-security.kubernetes.io/warn=baseline \
  pod-security.kubernetes.io/warn-version=latest \
  pod-security.kubernetes.io/audit=baseline \
  pod-security.kubernetes.io/audit-version=latest
kubectl -n argonix-sensor create secret generic argonix-sensor-credentials \
  --from-literal=ARGONIX_API_KEY="$ARGONIX_API_KEY"
```

Install from the Argonix repository:

```bash
helm repo add argonix https://charts.argonix.io
helm repo update argonix
helm upgrade --install argonix-sensor argonix/argonix-sensor \
  --namespace argonix-sensor \
  --set sensor.apiBaseUrl=https://api.example.com/api/0.1 \
  --set sensor.clusterName=production-eu
```

### Argo CD namespace configuration

When Argo CD owns namespace creation, leave `namespace.create=false`, keep
`CreateNamespace=true`, set `spec.destination.namespace=argonix-sensor`, and
configure:

```yaml
managedNamespaceMetadata:
  labels:
    pod-security.kubernetes.io/enforce: privileged
    pod-security.kubernetes.io/enforce-version: latest
    pod-security.kubernetes.io/warn: baseline
    pod-security.kubernetes.io/warn-version: latest
    pod-security.kubernetes.io/audit: baseline
    pod-security.kubernetes.io/audit-version: latest
```

The Argo CD `AppProject` must also permit the cluster-scoped policy resource:

```yaml
spec:
  clusterResourceWhitelist:
    - group: cilium.io
      kind: TracingPolicy
```

Without this entry Argo reports the policy as `Missing` and logs
`resource cilium.io:TracingPolicy is not permitted in project`. The CRD may
already exist; this is an AppProject authorization failure, not a CRD discovery
failure.

For a GitOps controller that does not manage namespace metadata, set
`namespace.create=true` so the chart renders the dedicated Namespace resource.

### CRDs and the default network policy

The standalone mode installs Tetragon CRDs and the Argonix network policy:

```yaml
tetragon:
  crds:
    installMethod: helm
sensor:
  tracingPolicy:
    enabled: true
```

If an existing Tetragon installation owns the CRDs, use
`tetragon.crds.installMethod=none`. Disable only the default
`argonix-network-connect` policy with `sensor.tracingPolicy.enabled=false`.
That fallback also disables Argonix's default TCP/UDP socket observations, so it
is not equivalent to a complete sensor installation.
The policy carries Argo CD first-sync annotations so a CRD discovery delay does
not fail dry-run reconciliation.

The upstream Tetragon DaemonSet runs one pod per Linux node. Each pod contains:

1. the privileged upstream Tetragon container;
2. the non-root Argonix collector sidecar;
3. a node-local 256 MiB spool volume shared only inside the pod.

The node name comes from the Kubernetes Downward API. Each node enrolls
idempotently as `kubernetes/<clusterName>/<nodeName>`.

Spool payloads are encrypted with Fernet before SQLite persistence. Add an
independent `ARGONIX_SPOOL_KEY` entry to `argonix-sensor-credentials` when
possible. Without it, version 0.1.7 derives the encryption key from the scoped
API key; drain the spool before rotating that API key.

## Existing Tetragon installation

Do not install two Tetragon DaemonSets on the same nodes. The initial supported
path is to replace the existing release with this wrapper chart while preserving
the upstream Tetragon values. Sidecar-only attachment to an independently
managed Tetragon release is a later packaging mode.

## Verify

```bash
kubectl -n argonix-system get daemonset,pods -l app.kubernetes.io/part-of=tetragon
kubectl -n argonix-system logs -l app.kubernetes.io/name=tetragon \
  -c export-stdout --tail=50
```

## Optional mTLS

The collector always requires its scoped Argonix API key. To additionally
authenticate the node at the TLS layer, create the optional fixed-name Secret:

```bash
kubectl -n argonix-system create secret tls argonix-sensor-mtls \
  --cert=node-client.crt \
  --key=node-client.key
```

The API ingress or service mesh must validate the client certificate against
the organization CA before forwarding the request to Django. If the Secret is
absent, the collector uses ordinary server-authenticated HTTPS. Automatic
certificate issuance and rotation are not part of version 0.1.7.

## Linux VM mode

VMs use the same Python package and API contract but not this Helm chart:

1. install upstream Tetragon as a package/container or `systemd` service;
2. export JSON events to `/var/log/tetragon/tetragon.log`;
3. run `argonix-sensor` as a separate `systemd` service with platform
  `vm_linux`, `ARGONIX_NODE_NAME` set to a stable cloud instance/host identity,
  and the same scoped API key.

Build or download the wheel, then install the hardened service:

```bash
sudo sensor/systemd/install.sh dist/argonix_sensor-0.1.7-py3-none-any.whl
sudo editor /etc/argonix-sensor/sensor.env
sudo systemctl start argonix-sensor
sudo systemctl status argonix-sensor
```

The collector runs unprivileged. Only upstream Tetragon needs kernel/eBPF
privileges. The service can read `/var/log/tetragon` and write only its private
state directory.
