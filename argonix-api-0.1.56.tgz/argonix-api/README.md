# Worker queues

Enable `finopsWorker.enabled` to deploy a dedicated worker consuming `finops`.
With this option enabled, the general worker consumes only `celery`. When it is
disabled (the default), the general worker consumes both queues for compatibility.
Deploy the new application image and chart 0.1.56 or later together.

FinOps collection, allocation, optimization, anomaly detection and budget tasks
route to `finops`. Agent investigations and approved remediation retain the
general worker's larger memory budget. Monitor tasks and monitor alert evaluation
and delivery route to `monitors`; external alert ingestion and AI investigations
remain on their existing queues.

Routing applies to newly published messages. Existing messages in `celery` drain
there; do not purge them during rollout. Explicit queue overrides on custom
DatabaseScheduler entries take precedence over application routes.

The dedicated FinOps worker defaults to one process, a 1Gi memory request and a
4Gi limit. Its 660-second shutdown grace accommodates the ten-minute cost-sync
and vSphere task limits. Other FinOps tasks can have different execution limits.
Size requests and limits against peak measurements after rollout.

# Memory

Celery startup does not load embedding/reranking models. The main Docker image
contains models downloaded at build time and runs HuggingFace in offline mode.
Models are still loaded lazily per process when RAG is used; the ONNX models and
1024-dimensional embedding format are unchanged, so reindexing is unnecessary.

`ARGOS_INFERENCE_BATCH_SIZE` (default 8, minimum 1) bounds inference batches for
embeddings and reranking. Set it using a worker's `env` values if needed. A smaller
batch reduces transient memory, but does not remove the model's resident memory.
Sharing that memory across workers would require a separate inference service.
Lowering Kubernetes memory requests reduces reservations, not actual process RSS.

# FinOps collection

Cost anomalies aggregate daily totals in one streaming query per organization;
only detected spikes require attribution/upsert queries. Missing baseline days
are not filled with zeros.

vSphere performance collection uses the existing connector, with at most 20 VMs
per SOAP request, a 60-second connection timeout, and progress saved per batch.
Inventory pagination reuses a connector-local snapshot for up to five minutes;
requesting page one refreshes it. Missing metrics, failed batches or truncated
inventory prevent automatic resolution of previous recommendations. A soft task
timeout marks the run failed; the hard limit is a final process safeguard.
