"""Exercise the wrapper against the packaged upstream dependency using Helm."""

import shutil
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

import yaml


CHART = Path(__file__).resolve().parent


def render(chart=CHART, *settings, values=None):
    command = ["helm", "template", "argonix-sensor", str(chart),
               "--set", "sensor.clusterName=ci",
               "--set", "tetragon.tetragon.nameOverride=tetragon"]
    for setting in settings:
        command.extend(["--set", setting])
    if values is not None:
        command.extend(["--values", str(values)])
    documents = [doc for doc in yaml.safe_load_all(
        subprocess.check_output(command, text=True)) if doc]
    identities = [(doc["kind"], doc["metadata"]["name"]) for doc in documents]
    if len(identities) != len(set(identities)):
        raise AssertionError("duplicate resources in sensor chart")
    return documents


def images(documents):
    daemonsets = [doc for doc in documents if doc["kind"] == "DaemonSet"]
    if len(daemonsets) != 1:
        raise AssertionError(f"expected one DaemonSet, got {len(daemonsets)}")
    return {item["name"]: item["image"] for item in
            daemonsets[0]["spec"]["template"]["spec"]["containers"]}


class SensorImageDefaults(unittest.TestCase):
    def test_defaults_and_example_values(self):
        version = str(yaml.safe_load((CHART / "Chart.yaml").read_text())["appVersion"])
        for values in (None, CHART.parents[1] / "docs/examples/sensor-values.yaml"):
            with self.subTest(values=values):
                settings = () if values is None else ("--values", str(values))
                output = subprocess.check_output([
                    "helm", "template", "argonix-sensor", str(CHART),
                    "--set", "sensor.clusterName=ci", *settings], text=True)
                self.assertEqual(images([doc for doc in yaml.safe_load_all(output) if doc]), {
                    "tetragon": f"ghcr.io/argonix-io/argonix-api-tetragon:{version}",
                    "export-stdout": f"ghcr.io/argonix-io/argonix-api-sensor:{version}",
                })

    def test_new_app_version_independent_of_chart_and_upstream_versions(self):
        with tempfile.TemporaryDirectory() as directory:
            chart = Path(directory) / "sensor"
            shutil.copytree(CHART, chart)
            metadata = yaml.safe_load((chart / "Chart.yaml").read_text())
            metadata.update(version="9.8.7", appVersion="9.8.6")
            (chart / "Chart.yaml").write_text(yaml.safe_dump(metadata))
            self.assertEqual(images(render(chart)), {
                "tetragon": "ghcr.io/argonix-io/argonix-api-tetragon:9.8.6",
                "export-stdout": "ghcr.io/argonix-io/argonix-api-sensor:9.8.6",
            })

    def test_custom_repositories_and_tags(self):
        self.assertEqual(images(render(CHART,
            "tetragon.tetragon.image.repository=registry.example/tetragon",
            "tetragon.tetragon.image.tag=agent-test",
            "tetragon.export.stdout.image.repository=registry.example/sensor",
            "tetragon.export.stdout.image.tag=collector-test")), {
                "tetragon": "registry.example/tetragon:agent-test",
                "export-stdout": "registry.example/sensor:collector-test",
            })

    def test_legacy_overrides_take_precedence(self):
        self.assertEqual(images(render(CHART,
            "tetragon.tetragon.image.override=registry.example/tetragon@sha256:123",
            "tetragon.tetragon.image.tag=ignored",
            "tetragon.export.stdout.image.override=registry.example/sensor:legacy",
            "tetragon.export.stdout.image.tag=ignored")), {
                "tetragon": "registry.example/tetragon@sha256:123",
                "export-stdout": "registry.example/sensor:legacy",
            })

    def test_agent_config_and_optional_monitoring(self):
        documents = render(CHART, "tetragon.tetragon.prometheus.serviceMonitor.enabled=true")
        self.assertTrue(any(doc["kind"] == "ConfigMap" and
                            doc["metadata"]["name"] == "tetragon-config" for doc in documents))
        self.assertTrue(any(doc["kind"] == "Service" and
                            doc["metadata"]["name"] == "tetragon" for doc in documents))
        self.assertTrue(any(doc["kind"] == "ServiceMonitor" for doc in documents))

    def test_export_exclusions_preserve_separate_upstream_filters(self):
        documents = render()
        config = next(doc for doc in documents if doc["kind"] == "ConfigMap" and
                      doc["metadata"]["name"] == "tetragon-config")
        filters = [json.loads(line) for line in config["data"]["export-denylist"].splitlines()]
        self.assertIn({"health_check": True}, filters)
        namespace_filter = next(item for item in filters if "namespace" in item)
        values = yaml.safe_load((CHART / "values.yaml").read_text())
        self.assertEqual(namespace_filter, {"namespace": values["sensor"]["excludeNamespaces"]})

    def test_empty_export_exclusions_keep_custom_filter(self):
        with tempfile.TemporaryDirectory() as directory:
            values = Path(directory) / "values.yaml"
            values.write_text(yaml.safe_dump({
                "sensor": {"excludeNamespaces": []},
                "tetragon": {"tetragon": {"exportDenyList":
                    json.dumps({"event_set": ["PROCESS_EXEC"]})}},
            }))
            documents = render(values=values)
        config = next(doc for doc in documents if doc["kind"] == "ConfigMap" and
                      doc["metadata"]["name"] == "tetragon-config")
        self.assertEqual(json.loads(config["data"]["export-denylist"]),
                         {"event_set": ["PROCESS_EXEC"]})


if __name__ == "__main__":
    unittest.main()
